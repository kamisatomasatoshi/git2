#include"DxLib.h"
#include"Player.h"

//�R���X�g���N�^
//���W�̏�����
Player::Player()
{
	defaultSpped = 4.0f;
	jumpCount = 1;
	jumpHeight = 10;

	goal = 0;

	isCopyed = 0;

	for (int i = 0; i < 8; i++)
	{
		hasCopy[i] = { 0 };
		hasReadyToCopy[i] = { 0 };
		serchCountMapchipX[i];
		serchCountMapchipY[i];
	}
	

	Transform serchTransform[8]
	{
		{ 0.0f},
		{ 0.0f},
		{ 0.0f},
		{ 0.0f},
		{ 16.0f,16.0f,16.0f,16.0f,16.0f,16.0f,16.0f,16.0f},
		{ 16.0f,16.0f,16.0f,16.0f,16.0f,16.0f,16.0f,16.0f},
		{ 0.0f},
		{ 0.0f}
	};

	CollisionPoint serchcollisionPoint[8]
	{
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0
	};



}

//�f�X�g���N�^
Player::~Player()
{
	delete object;
}

void Player::PlayerMoveCollision()
{
	//�E��
	object->collisionPoint.rightTopX = (object->transform.posX + object->transform.radiusX - 1) / BLOCK_SIZE;
	object->collisionPoint.rightTopY = (object->transform.posY - object->transform.radiusY) / BLOCK_SIZE;
	//�E��
	object->collisionPoint.rightBottomX = (object->transform.posX + object->transform.radiusX - 1) / BLOCK_SIZE;
	object->collisionPoint.rightBottomY = (object->transform.posY + object->transform.radiusY - 1) / BLOCK_SIZE;
	//����
	object->collisionPoint.leftTopX = (object->transform.posX - object->transform.radiusX) / BLOCK_SIZE;
	object->collisionPoint.leftTopY = (object->transform.posY - object->transform.radiusY) / BLOCK_SIZE;
	//����
	object->collisionPoint.leftBottomX = (object->transform.posX - object->transform.radiusX) / BLOCK_SIZE;
	object->collisionPoint.leftBottomY = (object->transform.posY + object->transform.radiusY - 1) / BLOCK_SIZE;
}

void Player::PlayerMove()
{
	
	object->transform.oldX = object->transform.posX;
	object->transform.oldY = object->transform.posY;

	PlayerMoveCollision();

	if (keys[KEY_INPUT_A] == 1)
	{
		if (object->transform.posX > BLOCK_SIZE) //��ʓ��œ����悤�ɔ͈͂�ݒ�
		{
			object->collisionPoint.rightTopX = ((object->transform.posX - object->transform.speedX) + object->transform.radiusX - 1) / BLOCK_SIZE;
			object->collisionPoint.rightBottomX = ((object->transform.posX - object->transform.speedX) + object->transform.radiusX - 1) / BLOCK_SIZE;
			object->collisionPoint.leftTopX = ((object->transform.posX - object->transform.speedX) - object->transform.radiusX) / BLOCK_SIZE;
			object->collisionPoint.leftBottomX = ((object->transform.posX - object->transform.speedX) - object->transform.radiusX) / BLOCK_SIZE;
			object->collisionPoint.leftTopY = (object->transform.posY - object->transform.radiusX) / BLOCK_SIZE;
			object->collisionPoint.leftBottomY = (object->transform.posY + object->transform.radiusX - 1) / BLOCK_SIZE;

			if (map[object->collisionPoint.leftTopY][object->collisionPoint.leftTopX] == BLOCK)
			{
				object->transform.speedX /= 2;

				//�c�ׂ�ɂ����ׂ�̗����ɐi�߂�
				if (map[object->collisionPoint.leftTopY][object->collisionPoint.leftTopX + 1] != BLOCK && map[object->collisionPoint.leftTopY + 1][object->collisionPoint.leftTopX] != BLOCK)
				{

				}
				//�c�ׂ�ɂ͐i�߂Ȃ������ׂ�ɂ͐i�߂�ꍇ
				else if (map[object->collisionPoint.leftTopY][object->collisionPoint.leftTopX + 1] == BLOCK && map[object->collisionPoint.leftTopY + 1][object->collisionPoint.leftTopX] != BLOCK)
				{
					object->transform.posY = object->transform.oldY;
				}
				//�c�ׂ�ɂ͐i�߂邪���ׂ�ɂ͐i�߂Ȃ��ꍇ
				else if (map[object->collisionPoint.leftTopY][object->collisionPoint.leftTopX + 1] != BLOCK && map[object->collisionPoint.leftTopY + 1][object->collisionPoint.leftTopX] == BLOCK)
				{
					object->transform.posX = object->transform.oldX;
				}
				//�c�ׂ�ɂ����ׂ�ɂ��i�߂Ȃ��ꍇ
				else if (map[object->collisionPoint.leftTopY][object->collisionPoint.leftTopX + 1] == BLOCK && map[object->collisionPoint.leftTopY + 1][object->collisionPoint.leftTopX] == BLOCK)
				{
					object->transform.posY = object->transform.oldY;
					object->transform.posX = object->transform.oldX;
				}
			}
			else if (map[object->collisionPoint.leftBottomY][object->collisionPoint.leftBottomX] == BLOCK)
			{
				object->transform.speedX /= 2;

				//�c�ׂ�ɂ����ׂ�̗����ɐi�߂�
				if (map[object->collisionPoint.leftBottomY][object->collisionPoint.leftBottomX + 1] != BLOCK && map[object->collisionPoint.leftBottomY - 1][object->collisionPoint.leftBottomX] != BLOCK)
				{

				}
				//�c�ׂ�ɂ͐i�߂Ȃ������ׂ�ɂ͐i�߂�ꍇ
				else if (map[object->collisionPoint.leftBottomY][object->collisionPoint.leftBottomX + 1] == BLOCK && map[object->collisionPoint.leftBottomY - 1][object->collisionPoint.leftBottomX] != BLOCK)
				{
					object->transform.posY = object->transform.oldY;
				}
				//�c�ׂ�ɂ͐i�߂邪���ׂ�ɂ͐i�߂Ȃ��ꍇ
				else if (map[object->collisionPoint.leftBottomY][object->collisionPoint.leftBottomX + 1] != BLOCK && map[object->collisionPoint.leftBottomY - 1][object->collisionPoint.leftBottomX] == BLOCK)
				{
					object->transform.posX = object->transform.oldX;
				}
				//�c�ׂ�ɂ����ׂ�ɂ��i�߂Ȃ��ꍇ
				else if (map[object->collisionPoint.leftBottomY][object->collisionPoint.leftBottomX + 1] == BLOCK && map[object->collisionPoint.leftBottomY - 1][object->collisionPoint.leftBottomX] == BLOCK)
				{
					object->transform.posY = object->transform.oldY;
					object->transform.posX = object->transform.oldX;
				}
			}
			else
			{
				object->transform.posX -= object->transform.speedX;
			}
		}
	}

	if (keys[KEY_INPUT_D] == 1)
	{
		if (object->transform.posX < MAP_SIZE_X * BLOCK_SIZE) //��ʓ��œ����悤�ɔ͈͂�ݒ�
		{
			object->collisionPoint.rightTopX = ((object->transform.posX + object->transform.speedX) + object->transform.radiusX - 1) / BLOCK_SIZE;
			object->collisionPoint.rightBottomX = ((object->transform.posX + object->transform.speedX) + object->transform.radiusX - 1) / BLOCK_SIZE;
			object->collisionPoint.leftTopX = ((object->transform.posX + object->transform.speedX) - object->transform.radiusX) / BLOCK_SIZE;
			object->collisionPoint.leftBottomX = ((object->transform.posX + object->transform.speedX) - object->transform.radiusX) / BLOCK_SIZE;
			object->collisionPoint.rightTopY = (object->transform.posY - object->transform.radiusY) / BLOCK_SIZE;
			object->collisionPoint.rightBottomY = (object->transform.posY + object->transform.radiusY - 1) / BLOCK_SIZE;

			//�u���b�N�ɓ��������ۂ̉����߂��̏���
			if (map[object->collisionPoint.rightTopY][object->collisionPoint.rightTopX] == BLOCK)
			{
				//�c�ׂ�ɂ����ׂ�̗����ɐi�߂�
				if (map[object->collisionPoint.rightTopY][object->collisionPoint.rightTopX - 1] != BLOCK && map[object->collisionPoint.rightTopY + 1][object->collisionPoint.rightTopX] != BLOCK)
				{

				}
				//�c�ׂ�ɂ͐i�߂Ȃ������ׂ�ɂ͐i�߂�ꍇ
				else if (map[object->collisionPoint.rightTopY][object->collisionPoint.rightTopX - 1] == BLOCK && map[object->collisionPoint.rightTopY + 1][object->collisionPoint.rightTopX] != BLOCK)
				{
					object->transform.posY = object->transform.oldY;
				}
				//�c�ׂ�ɂ͐i�߂邪���ׂ�ɂ͐i�߂Ȃ��ꍇ
				else if (map[object->collisionPoint.rightTopY][object->collisionPoint.rightTopX - 1] != BLOCK && map[object->collisionPoint.rightTopY + 1][object->collisionPoint.rightTopX] == BLOCK)
				{
					object->transform.posX = object->transform.oldX;
				}
				//�c�ׂ�ɂ����ׂ�ɂ��i�߂Ȃ��ꍇ
				else if (map[object->collisionPoint.rightTopY][object->collisionPoint.rightTopX - 1] == BLOCK && map[object->collisionPoint.rightTopY + 1][object->collisionPoint.rightTopX] == BLOCK)
				{
					object->transform.posY = object->transform.oldY;
					object->transform.posX = object->transform.oldX;
				}
			}
			else if (map[object->collisionPoint.rightBottomY][object->collisionPoint.rightBottomX] == BLOCK)
			{
				//�c�ׂ�ɂ����ׂ�̗����ɐi�߂�
				if (map[object->collisionPoint.rightBottomY][object->collisionPoint.rightBottomX - 1] != BLOCK && map[object->collisionPoint.rightBottomY - 1][object->collisionPoint.rightBottomX] != BLOCK)
				{

				}
				//�c�ׂ�ɂ͐i�߂Ȃ������ׂ�ɂ͐i�߂�ꍇ
				else if (map[object->collisionPoint.rightBottomY][object->collisionPoint.rightBottomX - 1] == BLOCK && map[object->collisionPoint.rightBottomY - 1][object->collisionPoint.rightBottomX] != BLOCK)
				{
					object->transform.posY = object->transform.oldY;
				}
				//�c�ׂ�ɂ͐i�߂邪���ׂ�ɂ͐i�߂Ȃ��ꍇ
				else if (map[object->collisionPoint.rightBottomY][object->collisionPoint.rightBottomX - 1] != BLOCK && map[object->collisionPoint.rightBottomY - 1][object->collisionPoint.rightBottomX] == BLOCK)
				{
					object->transform.posX = object->transform.oldX;
				}
				//�c�ׂ�ɂ����ׂ�ɂ��i�߂Ȃ��ꍇ
				else if (map[object->collisionPoint.rightBottomY][object->collisionPoint.rightBottomX - 1] == BLOCK && map[object->collisionPoint.rightBottomY - 1][object->collisionPoint.rightBottomX] == BLOCK)
				{
					object->transform.posY = object->transform.oldY;
					object->transform.posX = object->transform.oldX;
				}
			}
			else
			{
				object->transform.posX += object->transform.speedX;
			}
		}
	}

	if (keys[KEY_INPUT_S] == 1)
	{
		if (object->transform.posY < MAP_SIZE_Y * BLOCK_SIZE) //��ʓ��œ����悤�ɔ͈͂�ݒ�
		{
			object->collisionPoint.leftBottomX = (object->transform.posX - object->transform.radiusX) / BLOCK_SIZE;
			object->collisionPoint.rightBottomX = (object->transform.posX + object->transform.radiusX - 1) / BLOCK_SIZE;
			object->collisionPoint.leftTopY = ((object->transform.posY - object->transform.radiusY) + object->transform.speedY) / BLOCK_SIZE;
			object->collisionPoint.rightTopY = ((object->transform.posY - object->transform.radiusY) + object->transform.speedY) / BLOCK_SIZE;
			object->collisionPoint.leftBottomY = ((object->transform.posY + object->transform.radiusY - 1) + object->transform.speedY) / BLOCK_SIZE;
			object->collisionPoint.rightBottomY = ((object->transform.posY + object->transform.radiusY - 1) + object->transform.speedY) / BLOCK_SIZE;

			//�u���b�N�ɓ��������ۂ̉����߂��̏���
			if (map[object->collisionPoint.leftBottomY][object->collisionPoint.leftBottomX] == BLOCK)
			{
				//�c�ׂ�ɂ����ׂ�̗����ɐi�߂�
				if (map[object->collisionPoint.leftBottomY][object->collisionPoint.leftBottomX + 1] != BLOCK && map[object->collisionPoint.leftBottomY - 1][object->collisionPoint.leftBottomX] != BLOCK)
				{

				}
				//�c�ׂ�ɂ͐i�߂Ȃ������ׂ�ɂ͐i�߂�ꍇ
				else if (map[object->collisionPoint.leftBottomY][object->collisionPoint.leftBottomX + 1] == BLOCK && map[object->collisionPoint.leftBottomY - 1][object->collisionPoint.leftBottomX] != BLOCK)
				{
					object->transform.posY = object->transform.oldY;
				}
				//�c�ׂ�ɂ͐i�߂邪���ׂ�ɂ͐i�߂Ȃ��ꍇ
				else if (map[object->collisionPoint.leftBottomY][object->collisionPoint.leftBottomX + 1] != BLOCK && map[object->collisionPoint.leftBottomY - 1][object->collisionPoint.leftBottomX] == BLOCK)
				{
					object->transform.posX = object->transform.oldX;
				}
				//�c�ׂ�ɂ����ׂ�ɂ��i�߂Ȃ��ꍇ
				else if (map[object->collisionPoint.leftBottomY][object->collisionPoint.leftBottomX + 1] == BLOCK && map[object->collisionPoint.leftBottomY - 1][object->collisionPoint.leftBottomX] == BLOCK)
				{
					object->transform.posY = object->transform.oldY;
					object->transform.posX = object->transform.oldX;
				}
			}
			else if (map[object->collisionPoint.rightBottomY][object->collisionPoint.rightBottomX] == BLOCK)
			{
				//�c�ׂ�ɂ����ׂ�̗����ɐi�߂�
				if (map[object->collisionPoint.rightBottomY][object->collisionPoint.rightBottomX - 1] != BLOCK && map[object->collisionPoint.rightBottomY - 1][object->collisionPoint.rightBottomX] != BLOCK)
				{

				}
				//�c�ׂ�ɂ͐i�߂Ȃ������ׂ�ɂ͐i�߂�ꍇ
				else if (map[object->collisionPoint.rightBottomY][object->collisionPoint.rightBottomX - 1] == BLOCK && map[object->collisionPoint.rightBottomY - 1][object->collisionPoint.rightBottomX] != BLOCK)
				{
					object->transform.posY = object->transform.oldY;
				}
				//�c�ׂ�ɂ͐i�߂邪���ׂ�ɂ͐i�߂Ȃ��ꍇ
				else if (map[object->collisionPoint.rightBottomY][object->collisionPoint.rightBottomX - 1] != BLOCK && map[object->collisionPoint.rightBottomY - 1][object->collisionPoint.rightBottomX] == BLOCK)
				{
					object->transform.posX = object->transform.oldX;
				}
				//�c�ׂ�ɂ����ׂ�ɂ��i�߂Ȃ��ꍇ
				else if (map[object->collisionPoint.rightBottomY][object->collisionPoint.rightBottomX - 1] == BLOCK && map[object->collisionPoint.rightBottomY - 1][object->collisionPoint.rightBottomX] == BLOCK)
				{
					object->transform.posY = object->transform.oldY;
					object->transform.posX = object->transform.oldX;
				}
			}
			else
			{
				object->transform.posY += object->transform.speedY;
			}
		}
	}	

	//�X�s�[�h���K��l�ɖ߂�
	object->transform.speedX = defaultSpped;
	object->transform.speedY = defaultSpped;

	//�ǂ����̃}�b�v�����������瑬�x�𔼕��ɂ���B
	if (map[object->collisionPoint.leftTopY][object->collisionPoint.leftTopX] == BLOCK || map[object->collisionPoint.rightTopY][object->collisionPoint.rightTopX] == BLOCK || map[object->collisionPoint.leftBottomY][object->collisionPoint.leftBottomX] == BLOCK || map[object->collisionPoint.rightBottomY][object->collisionPoint.rightBottomX] == BLOCK)
	{
		object->transform.speedX /= 2;
		object->transform.speedY /= 2;
	}
	//�����Ȃ��΂߈ړ��̍ۂɁA�X�s�[�h�𔼕��ɂ���B
	/*else if (keys[KEY_INPUT_W] == 1 && keys[KEY_INPUT_D] == 1)
	{
		object->transform.speedX /= 2;
		object->transform.speedY /= 2;
	}
	else if (keys[KEY_INPUT_W] == 1 && keys[KEY_INPUT_A] == 1)
	{
		object->transform.speedX /= 2;
		object->transform.speedY /= 2;
	}*/
	else if (keys[KEY_INPUT_S] == 1 && keys[KEY_INPUT_D] == 1)
	{
		object->transform.speedX /= 2;
		object->transform.speedY /= 2;
	}
	else if (keys[KEY_INPUT_S] == 1 && keys[KEY_INPUT_A] == 1)
	{
		object->transform.speedX /= 2;
		object->transform.speedY /= 2;
	}

	//object->ObjectMoveCollision();

	object->gravity();

	//�v���C���[�̃W�����v
	if (jumpCount > 0) {
		if (map[object->collisionPoint.leftTopY][object->collisionPoint.leftTopX] != BLOCK || map[object->collisionPoint.rightTopY][object->collisionPoint.rightTopX] != BLOCK) {
			if (keys[KEY_INPUT_W] == 1 && oldkeys[KEY_INPUT_W] == 0) {
				object->isFlying = 1;
				object->gravitySpeed = 0;
				jumpCount -= 1;
				jumpHeight = MAX_JUMP;

				////���ʉ�
				//StopSoundMem(jumpSound);
				//if (CheckSoundMem(jumpSound) == 0) {
				//	PlaySoundMem(jumpSound, DX_PLAYTYPE_BACK, true);
				//}
			}
		}
	}
	//�W�����v�̎d�g��
	if (jumpCount < 1)
	{
		if (object->isFlying == 1)
		{
			jumpHeight--;
			if (jumpHeight < -10) {
				jumpHeight = -10;
			}

			object->transform.posY -= jumpHeight;
		}
	}

	//�n�ʂɒ��n������ēx�W�����v�ł���悤�ɂ���
	if (jumpCount == 0) {
		if (map[object->collisionPoint.leftBottomY][object->collisionPoint.leftBottomX] == BLOCK || map[object->collisionPoint.rightBottomY][object->collisionPoint.rightBottomX] == BLOCK)
		{
			jumpCount = 1;
		}
	}

	object->fallProcess();

	//���ł���Ƃ�
	if (jumpCount < 1) {
		//������Ńu���b�N�ɂԂ��������̏���
		/*if (object->transform.posY <= (object->BottomYHeightPlus - object->transform.radiusY))
		{*/
			if (map[object->collisionPoint.leftTopY][object->collisionPoint.leftTopX] == BLOCK || map[object->collisionPoint.rightTopY][object->collisionPoint.rightTopX] == BLOCK) 
			{
				object->transform.posY = object->BottomYHeight;
				jumpHeight = 0;
			}
		//}
	}

	//�������Ƀu���b�N�ɂԂ��������̏���
	if (map[object->collisionPoint.leftBottomY][object->collisionPoint.leftBottomX] == BLOCK || map[object->collisionPoint.rightBottomY][object->collisionPoint.rightBottomX] == BLOCK)
	{
		jumpCount = 1;
		jumpHeight = 15;
	}

	//�n�ʂƐڂ��Ă���Ƃ�
	if (object->transform.posY >= (MAP_HEIGHT - 1) * BLOCK_SIZE - object->transform.radiusY) 
	{
		jumpCount = 1;
		jumpHeight = 20;
	}

	//�S�[������
	if (map[object->collisionPoint.leftTopY][object->collisionPoint.leftTopX] == GOAL || map[object->collisionPoint.rightTopY][object->collisionPoint.rightTopX] == GOAL
		|| map[object->collisionPoint.leftBottomY][object->collisionPoint.leftBottomX] == GOAL || map[object->collisionPoint.rightBottomY][object->collisionPoint.rightBottomX] == GOAL)
	{
		goal = 1;
	}
}

void Player::PlayerDraw()
{
	/*if (keys[KEY_INPUT_LCONTROL] == 1)
	{
		if (keys[KEY_INPUT_C] == 1)
		{
			for (int y = (object->transform.posY - object->transform.radiusY) / BLOCK_SIZE - 1; y < (object->transform.posY + object->transform.radiusY) / BLOCK_SIZE + 1; y++)
			{
				for (int x = (object->transform.posX - object->transform.radiusX) / BLOCK_SIZE - 1; x < (object->transform.posX + object->transform.radiusX) / BLOCK_SIZE + 1; x++)
				{
					for (int z = -1; z < 2; z++)
					{
						for (int a = -1; a < 2; a++)
						{
							if (map[y][x] == 1)
							{
								searchMap[y][x] = 1;
							}

							DrawFormatString(0, 20 * y, GetColor(255, 255, 255), "searchMap[%d][%d]", y, x);
						}
					}

				}
			}
		}
	}*/

	/*DrawFormatString(200, 200, GetColor(255, 255, 255), "playerTransform.posX %f", playerTransform.posX);
	DrawFormatString(200, 300, GetColor(255, 255, 255), "object->transform.posX %f", object->transform.posX);
	DrawFormatString(200, 320, GetColor(255, 255, 255), "object->isFlying %d", object->isFlying);
	DrawFormatString(200, 340, GetColor(255, 255, 255), "jumpCount %d", jumpCount);
	DrawFormatString(200, 360, GetColor(255, 255, 255), "jumpHeight %d", jumpHeight);*/

	//DrawFormatString(200, 300, GetColor(255, 255, 255), "object->isFlying %f", object->isFlying);
}

void Player::Copy()
{
	// 012
	// 3 4
	// 567
	  
	//X���W�̏�����
	for (int i = 0; i < 8; i++)
	{
		if (i == 0 || i == 3 || i == 5)
		{
			serchTransform[i].posX = object->transform.posX - (object->transform.radiusX * 2);
		}
		else if(i == 2 || i == 4 || i == 7)
		{
			serchTransform[i].posX = object->transform.posX + (object->transform.radiusX * 2);
		}
		else if(i == 1 || i == 6)
		{
			serchTransform[i].posX = object->transform.posX ;
		}
	}
	//Y���W�̏�����
	for (int i = 0; i < 8; i++)
	{
		if (i <= 2)
		{
			serchTransform[i].posY = object->transform.posY - (object->transform.radiusY * 2);
		}
		else if (i >= 5)
		{
			serchTransform[i].posY = object->transform.posY + (object->transform.radiusY * 2);
		}
		else if (i == 3 || i == 4)
		{
			serchTransform[i].posY = object->transform.posY;
		}
	}

	for (int i = 0; i < 8; i++)
	{
		//�E��
		serchcollisionPoint[i].rightTopX = (serchTransform[i].posX  + serchTransform[i].radiusX - 1) / BLOCK_SIZE;
		serchcollisionPoint[i].rightTopY = (serchTransform[i].posY - serchTransform[i].radiusY) / BLOCK_SIZE;
		//�E��
		serchcollisionPoint[i].rightBottomX = (serchTransform[i].posX  + serchTransform[i].radiusX - 1) / BLOCK_SIZE;
		serchcollisionPoint[i].rightBottomY = (serchTransform[i].posY + serchTransform[i].radiusY - 1) / BLOCK_SIZE;
		//����
		serchcollisionPoint[i].leftTopX = (serchTransform[i].posX  - serchTransform[i].radiusX) / BLOCK_SIZE;
		serchcollisionPoint[i].leftTopY = (serchTransform[i].posY - serchTransform[i].radiusY) / BLOCK_SIZE;
		//����
		serchcollisionPoint[i].leftBottomX = (serchTransform[i].posX  - serchTransform[i].radiusX) / BLOCK_SIZE;
		serchcollisionPoint[i].leftBottomY = (serchTransform[i].posY + serchTransform[i].radiusY - 1) / BLOCK_SIZE;
	}

	for (int i = 0; i < 8; i++)
	{
		serchCountMapchipX[i] = serchTransform[i].posX / BLOCK_SIZE;
		serchCountMapchipY[i] = serchTransform[i].posY / BLOCK_SIZE;
	}

	for (int i = 0; i < 8; i++)
	{
		if (map[serchCountMapchipY[i]][serchCountMapchipX[i]] == BLOCK)
		{
			hasReadyToCopy[i] = 1;

			if (keys[KEY_INPUT_LCONTROL] == 1)
			{
				if (keys[KEY_INPUT_C] == 1)
				{
					hasCopy[i] = 1;
				}
			}

			if (keys[KEY_INPUT_LCONTROL] == 1)
			{
				if (keys[KEY_INPUT_X] == 1)
				{
					hasCopy[i] = 1;
					map[serchCountMapchipY[i]][serchCountMapchipX[i]] = NONE;
				}
			}
		}
		else
		{
			hasReadyToCopy[i] = 0;
		}

		if (hasCopy[i] == 1 && map[serchCountMapchipY[i]][serchCountMapchipX[i]] == NONE)
		{
			if (keys[KEY_INPUT_LCONTROL] == 1)
			{
				if (keys[KEY_INPUT_V] == 1)
				{
					hasCopy[i] = 0;
					map[serchCountMapchipY[i]][serchCountMapchipX[i]] = BLOCK;
				}
			}
		}
	}

	

	for (int i = 0; i < 8; i++)
	{
		DrawCircle(serchTransform[i].posX, serchTransform[i].posY, serchTransform[i].radiusX, GetColor(255, 255, 255), TRUE);
	}

}
