#pragma once
#include"Global.h"

//�}�b�v�`�b�v
enum MapInfo
{
	NONE,
	BLOCK,
	START,
	GOAL
};

extern int map[MAP_HEIGHT][MAP_WIDTH] ;

extern int searchMap[MAP_HEIGHT][MAP_WIDTH];

