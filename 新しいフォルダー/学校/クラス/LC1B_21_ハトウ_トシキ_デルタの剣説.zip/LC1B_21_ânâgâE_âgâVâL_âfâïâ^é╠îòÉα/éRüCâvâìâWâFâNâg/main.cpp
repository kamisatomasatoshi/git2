#include "DxLib.h"
#include "main.h"

// �E�B���h�E�̃^�C�g���ɕ\�����镶����
const char TITLE[] = "LC1A_20_�n�g�E�g�V�L: �^�C�g��";

// �E�B���h�E����
const int WIN_WIDTH = 1792;

// �E�B���h�E�c��
const int WIN_HEIGHT = 864;

int WINAPI WinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ LPSTR lpCmdLine,
	_In_ int nCmdShow) {
	// �E�B���h�E���[�h�ɐݒ�
	ChangeWindowMode(TRUE);

	// �E�B���h�E�T�C�Y���蓮�ł͕ύX�������A
	// ���E�B���h�E�T�C�Y�ɍ��킹�Ċg��ł��Ȃ��悤�ɂ���
	SetWindowSizeChangeEnableFlag(FALSE, FALSE);

	// �^�C�g����ύX
	SetMainWindowText(TITLE);

	// ��ʃT�C�Y�̍ő�T�C�Y�A�J���[�r�b�g����ݒ�(���j�^�[�̉𑜓x�ɍ��킹��)
	SetGraphMode(WIN_WIDTH, WIN_HEIGHT, 32);

	// ��ʃT�C�Y��ݒ�(�𑜓x�Ƃ̔䗦�Őݒ�)
	SetWindowSizeExtendRate(1.0);

	// ��ʂ̔w�i�F��ݒ肷��
	SetBackgroundColor(0x00, 0x00, 0x00);

	// DXlib�̏�����
	if (DxLib_Init() == -1) { return -1; }

	// (�_�u���o�b�t�@)�`���O���t�B�b�N�̈�͗��ʂ��w��
	SetDrawScreen(DX_SCREEN_BACK);

	// �摜�Ȃǂ̃��\�[�X�f�[�^�̕ϐ��錾�Ɠǂݍ���
	int tile = LoadGraph("gameTile.png");
	int block = LoadGraph("gameBlock.png");
	int wall = LoadGraph("gameWall.png");
	int boss1 = LoadGraph("gameBoss.png");
	int boss2 = LoadGraph("gameBossDamage.png");
	int attackUp = LoadGraph("gamePlayerAttackUp.png");
	int attackDown = LoadGraph("gamePlayerAttackDown.png");
	int attackLeft = LoadGraph("gamePlayerAttackLeft.png");
	int attackRight = LoadGraph("gamePlayerAttackRight.png");
	int playerHp3 = LoadGraph("HP3.png");
	int playerHp2 = LoadGraph("HP2.png");
	int playerHp1 = LoadGraph("HP1.png");
	int playerHp0 = LoadGraph("HP0.png");
	int enemy1 = LoadGraph("gameEnemy1.png");
	int enemy1Down = LoadGraph("gameEnemyDown.png");
	int enemy1Right = LoadGraph("gameEnemyRight.png");
	int enemy1Left = LoadGraph("gameEnemyLeft.png");
	int enemy2 = LoadGraph("gameEnemy2.png");
	int enemy2Left = LoadGraph("gameEnemy2Left.png");
	int enemy2Right = LoadGraph("gameEnemy2Right.png");
	int enemyDeath = LoadGraph("gameEnemyDeath.png");
	int enemyBullet = LoadGraph("bullet.png");
	int texBossBullet = LoadGraph("bossBullet.png");
	int texFors = LoadGraph("fors.png");
	int GHandle[2];
	int GHandle1[2];
	int GHandle2[2];
	int GHandle3[2];
	int GHandle4[2];
	LoadDivGraph("gamePlayerUp.png", 2, 2, 1, 32, 32, GHandle);
	LoadDivGraph("gamePlayerUp.png", 2, 2, 1, 32, 32, GHandle1);
	LoadDivGraph("gamePlayerDown.png", 2, 2, 1, 32, 32, GHandle2);
	LoadDivGraph("gamePlayerLeft.png", 2, 2, 1, 32, 32, GHandle3);
	LoadDivGraph("gamePlayerRight.png", 2, 2, 1, 32, 32, GHandle4);
	int title = LoadGraph("title.png");
	int end1 = LoadGraph("gameEnd.png");

	// �Q�[�����[�v�Ŏg���ϐ��̐錾

	int map[mapSizeY][mapSizeX]
	{
		{3,3,3,3,3,3,3,3,3,3,3,3,3,3, 3,3,3,3,3,3,3,3,3,3,3,3,3,3, 3,3,3,3,3,3,3,3,3,3,3,3,3,3, 3,3,3,3,3,3,3,3,3,3,3,3,3,3},
		{3,0,0,0,0,0,0,0,0,0,0,0,0,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,3},
		{3,0,0,0,0,0,1,0,0,0,0,0,0,3, 3,0,1,1,0,0,0,0,0,0,1,1,0,3, 3,0,0,0,0,0,1,1,0,0,0,0,0,3, 3,0,1,0,1,0,1,1,0,1,0,1,0,3},
		{3,0,0,0,1,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0,0,0,0,3, 3,0,0,1,0,0,0,0,0,0,1,0,0,0, 0,0,0,0,0,0,1,1,0,0,0,0,0,3},
		{3,0,0,0,0,0,1,1,0,0,0,0,0,0, 0,0,0,0,0,0,1,1,0,0,0,0,0,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,0, 0,0,1,0,1,0,1,1,0,1,0,1,0,3},
		{3,0,0,0,0,0,0,0,0,1,1,1,1,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,3, 3,0,0,1,0,0,0,0,0,0,1,0,0,3, 3,0,0,0,0,0,1,1,0,0,0,0,0,3},
		{3,0,0,0,0,0,0,1,0,1,1,1,1,3, 3,0,1,1,0,0,0,0,0,0,1,1,0,3, 3,0,0,0,0,0,1,1,0,0,0,0,0,3, 3,0,1,0,1,0,1,1,0,1,0,1,0,3},
		{3,0,0,0,0,0,0,0,0,1,1,1,1,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,3},
		{3,3,3,3,3,3,0,0,3,3,3,3,3,3, 3,3,3,3,3,3,0,0,3,3,3,3,3,3, 3,3,3,3,3,3,0,0,3,3,3,3,3,3, 3,3,3,3,3,3,0,0,3,3,3,3,3,3},

		{3,3,3,3,3,3,0,0,3,3,3,3,3,3, 3,3,3,3,3,3,0,0,3,3,3,3,3,3, 3,3,3,3,3,3,0,0,3,3,3,3,3,3, 3,3,3,3,3,3,0,0,3,3,3,3,3,3},
		{3,1,1,0,0,0,0,0,0,0,0,1,1,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,3},
		{3,0,0,0,0,0,0,0,0,0,0,0,0,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,3, 3,0,0,1,0,0,0,0,0,0,0,0,0,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,3},
		{3,0,0,0,0,0,1,1,0,0,0,0,0,3, 3,0,0,1,0,0,0,0,0,0,1,0,0,0, 0,0,0,0,0,0,0,0,0,0,1,0,0,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,3},
		{3,0,0,0,0,0,1,1,0,0,0,0,0,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0,0,0,0,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,3},
		{3,0,0,0,0,0,1,1,0,0,0,0,0,3, 3,0,0,1,0,0,0,0,0,0,1,0,0,3, 3,0,0,1,0,0,0,0,0,0,0,0,0,3, 3,1,0,0,0,0,0,0,0,0,0,0,1,3},
		{3,0,0,0,0,0,0,0,0,0,0,0,0,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,3, 3,0,0,0,0,0,0,0,0,0,1,0,0,3, 3,1,1,1,0,0,0,0,0,0,1,1,1,3},
		{3,1,1,0,0,0,0,0,0,0,0,1,1,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,3, 3,1,1,1,1,1,0,0,1,1,1,1,1,3},
		{3,3,3,3,3,3,0,0,3,3,3,3,3,3, 3,3,3,3,3,3,3,3,3,3,3,3,3,3, 3,3,3,3,3,3,3,3,3,3,3,3,3,3, 3,3,3,3,3,3,0,0,3,3,3,3,3,3},

		{3,3,3,3,3,3,0,0,3,3,3,3,3,3, 3,3,3,3,3,3,3,3,3,3,3,3,3,3, 3,3,3,3,3,3,3,3,3,3,3,3,3,3, 3,3,3,3,3,3,0,0,3,3,3,3,3,3},
		{3,0,0,0,0,0,0,0,1,1,1,0,0,0, 0,0,0,0,0,0,0,0,0,0,0,0,0,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,3},
		{3,0,0,0,0,0,1,1,1,1,0,0,0,3, 3,0,1,1,0,0,0,0,0,0,0,0,0,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,3, 3,0,1,1,1,1,0,0,1,1,1,1,0,3},
		{3,0,0,0,0,1,1,1,1,0,0,0,0,0, 0,0,0,0,0,0,1,1,0,0,0,0,0,0, 0,0,0,1,1,0,0,0,0,1,1,0,0,3, 3,0,1,0,0,0,0,0,0,0,0,1,0,3},
		{3,0,0,0,1,1,1,1,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,0,0,1,1,0,0, 0,0,0,1,1,0,0,0,0,1,1,0,0,3, 3,0,1,0,0,0,0,0,0,0,0,1,0,3},
		{3,0,0,1,1,1,1,0,0,0,0,0,0,3, 3,0,0,1,1,0,0,0,0,0,0,0,0,3, 3,0,0,1,1,0,0,0,0,1,1,0,0,3, 3,0,1,0,0,0,0,0,0,0,0,1,0,3},
		{3,0,1,1,1,0,0,0,0,0,0,0,0,3, 3,0,0,0,0,0,0,1,1,0,0,0,0,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,3, 3,0,1,1,1,1,1,1,1,1,1,1,0,3},
		{3,0,0,0,0,0,0,0,0,0,0,0,0,3, 3,0,0,0,0,0,0,0,0,0,0,1,1,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,3, 3,0,0,0,0,0,0,0,0,0,0,0,0,3},
		{3,3,3,3,3,3,3,3,3,3,3,3,3,3, 3,3,3,3,3,3,3,3,3,3,3,3,3,3, 3,3,3,3,3,3,3,3,3,3,3,3,3,3, 3,3,3,3,3,3,3,3,3,3,3,3,3,3},
	};

	// �ŐV�̃L�[�{�[�h���p
	char keys[256] = { 0 };

	// 1���[�v(�t���[��)�O�̃L�[�{�[�h���
	char oldkeys[256] = { 0 };

	// �Q�[�����[�v
	while (true) {
		// �ŐV�̃L�[�{�[�h��񂾂������̂�1�t���[���O�̃L�[�{�[�h���Ƃ��ĕۑ�
		// �ŐV�̃L�[�{�[�h�����擾
		GetHitKeyStateAll(keys);

		// ��ʃN���A
		ClearDrawScreen();
		//---------  ��������v���O�������L�q  ----------//

		// �X�V����
		if (keys[KEY_INPUT_RETURN] == 1 && oldkeys[KEY_INPUT_RETURN] == 0 && scene < 1)
		{
			scene++;
		}
		if (scene == 1)
		{
			timer++;
			if (timer == 10)
			{
				i++;
				if (i == 2)i = 0;
				timer = 0;
			}

			if (keys[KEY_INPUT_UP] == 1 && player.y - player.r > 0)
			{
				leftTopY = ((player.y + scroll.y - speedTmp) - player.r) / blockSize;
				rightTopY = ((player.y + scroll.y - speedTmp) - player.r) / blockSize;
				if (map[leftTopY][leftTopX] == NONE && map[rightTopY][rightTopX] == NONE)
				{
					player.speedY = -4;
				}
				else
				{
					player.speedY = 0;
				}
				player.y += player.speedY;
			}
			if (keys[KEY_INPUT_DOWN] == 1 && player.y + player.r + blockSize < end.y)
			{
				leftBottomY = ((player.y + scroll.y + speedTmp) + player.r - 1) / blockSize;
				rightBottomY = ((player.y + scroll.y + speedTmp) + player.r - 1) / blockSize;
				if (map[leftBottomY][leftBottomX] == NONE && map[rightBottomY][rightBottomX] == NONE)
				{
					player.speedY = 4;
				}
				else
				{
					player.speedY = 0;
				}
				player.y += player.speedY;
			}
			if (keys[KEY_INPUT_LEFT] == 1 && player.x - player.r > 0)
			{
				leftTopX = ((player.x + scroll.x - speedTmp) - player.r) / blockSize;
				leftBottomX = ((player.x + scroll.x - speedTmp) - player.r) / blockSize;
				if (map[leftTopY][leftTopX] == NONE && map[leftBottomY][leftBottomX] == NONE)
				{
					player.speedX = -4;
				}
				else
				{
					player.speedX = 0;
				}
				player.x += player.speedX;
			}
			if (keys[KEY_INPUT_RIGHT] == 1 && player.x + player.r < WIN_WIDTH)
			{
				rightTopX = ((player.x + scroll.x + speedTmp + scroll.x) + player.r - 1) / blockSize;
				rightBottomX = ((player.x + scroll.x + speedTmp + scroll.x) + player.r - 1) / blockSize;
				if (map[rightTopY][rightTopX] == NONE && map[rightBottomY][rightBottomX] == NONE)
				{
					player.speedX = 4;
				}
				else
				{
					player.speedX = 0;
				}
				player.x += player.speedX;
			}

			leftTopX = (player.x - player.r) / blockSize;
			leftTopY = (player.y - player.r) / blockSize;
			leftBottomX = (player.x - player.r) / blockSize;
			leftBottomY = (player.y + player.r - 1) / blockSize;

			rightTopX = (player.x + player.r - 1) / blockSize;
			rightTopY = (player.y - player.r) / blockSize;
			rightBottomX = (player.x + player.r - 1) / blockSize;
			rightBottomY = (player.y + player.r - 1) / blockSize;

			Box sword =
			{
				player.x - player.r,
				player.y - player.r,
				32
			};

			if (keys[KEY_INPUT_SPACE] == 1)
			{
				if (GHandle[i] == GHandle1[i])
				{
					sword.y = player.y - player.r * 3;
				}
				else if (GHandle[i] == GHandle2[i])
				{
					sword.y = player.y + player.r;
				}
				else if (GHandle[i] == GHandle3[i])
				{
					sword.x = player.x - player.r * 3;
				}
				else if (GHandle[i] == GHandle4[i])
				{
					sword.x = player.x + player.r;
				}
			}

			for (int i = 0; i < enemyNum; i++)
			{
				if (box_collision(sword.x, sword.y, sword.r, enemy[i].x, enemy[i].y, enemy[i].r))
				{
					enemy[i].hp--;
				}
			}

			if (enemy[0].hp > 0)
			{
				bullet[0].y = bullet[0].y + bulletSpeed[0];
				if (bullet[0].y + bullet[0].r == WIN_HEIGHT - blockSize)
				{
					bulletSpeed[0] = bulletSpeed[0] * -1;
				}
				else if (bullet[0].y == enemy[0].y)
				{
					bulletSpeed[0] = bulletSpeed[0] * -1;
				}
			}
			if (enemy[1].hp > 0)
			{
				bullet[1].x = bullet[1].x + bulletSpeed[1];
				if (bullet[1].x + bullet[1].r == 6 * blockSize)
				{
					bulletSpeed[1] = bulletSpeed[1] * -1;
				}
				else if (bullet[1].x == enemy[1].x)
				{
					bulletSpeed[1] = bulletSpeed[1] * -1;
				}
			}
			if (enemy[2].hp > 0)
			{
				bullet[2].x = bullet[2].x - bulletSpeed[2];
				if (bullet[2].x == 8 * blockSize)
				{
					bulletSpeed[2] = bulletSpeed[2] * -1;
				}
				else if (bullet[2].x + bullet[2].r == 13 * blockSize)
				{
					bulletSpeed[2] = bulletSpeed[2] * -1;
				}
			}
			if (enemy[3].hp > 0)
			{
				bullet[3].y = bullet[3].y - bulletSpeed[3];
				if (bullet[3].y == 5 * blockSize)
				{
					bulletSpeed[3] = bulletSpeed[3] * -1;
				}
				else if (bullet[3].y + bullet[3].r == 17 * blockSize)
				{
					bulletSpeed[3] = bulletSpeed[3] * -1;
				}
			}
			if (enemy[4].hp > 0)
			{
				bullet[4].y = bullet[4].y - bulletSpeed[4];
				if (bullet[4].y == 5 * blockSize)
				{
					bulletSpeed[4] = bulletSpeed[4] * -1;
				}
				else if (bullet[4].y + bullet[4].r == 17 * blockSize)
				{
					bulletSpeed[4] = bulletSpeed[4] * -1;
				}
			}
			if (enemy[5].hp > 0)
			{
				bullet[5].x = bullet[5].x - bulletSpeed[5];
				if (bullet[5].x == 15 * blockSize)
				{
					bulletSpeed[5] = bulletSpeed[5] * -1;
				}
				else if (bullet[5].x + bullet[5].r == 41 * blockSize)
				{
					bulletSpeed[5] = bulletSpeed[5] * -1;
				}
			}
			if (enemy[6].hp > 0)
			{
				bullet[6].y = bullet[6].y - bulletSpeed[6];
				if (bullet[6].y == 7 * blockSize)
				{
					bulletSpeed[6] = bulletSpeed[6] * -1;
				}
				else if (bullet[6].y - bullet[6].r == enemy[6].y)
				{
					bulletSpeed[6] = bulletSpeed[6] * -1;
				}
			}
			if (enemy[7].hp > 0)
			{
				bullet[7].x = bullet[7].x + bulletSpeed[7];
				if (bullet[7].x + bullet[7].r == 9 * blockSize)
				{
					bulletSpeed[7] = bulletSpeed[7] * -1;
				}
				else if (bullet[7].x == blockSize)
				{
					bulletSpeed[7] = bulletSpeed[7] * -1;
				}
			}

			for (int i = 0; i < enemyNum; i++)
			{
				if (enemy[i].hp > 0)
				{
					if (box_collision(bullet[i].x, bullet[i].y, bullet[i].r, player.x - player.r, player.y - player.r, player.r * 2))
					{
						hitFlag[i] = 1;
						hitFlag[i] = 0;
					}
				}
			}
			if (hitFlag[i] == 1)
			{
				playerHp = playerHp - bulletDamage;
			}

			if (bossHp > 0)
			{
				for (int i = 0; i < bossBulletNum; i++)
				{
					bossBullet[i].x = bossBullet[i].x + bossBulletSpeedX[i];
					bossBullet[i].y = bossBullet[i].y + bossBulletSpeedY[i];
					if (bossBullet[i].x + bossBullet[i].r == 55 * blockSize)
					{
						bossBulletSpeedX[i] = bossBulletSpeedX[i] * -1;
					}
					else if (bossBullet[i].x == 43 * blockSize)
					{
						bossBulletSpeedX[i] = bossBulletSpeedX[i] * -1;
					}
					if (bossBullet[0].y + bossBullet[0].r == 17 * blockSize)
					{
						bossBulletSpeedY[0] = bossBulletSpeedY[0] * -1;
					}
					else if (bossBullet[0].y == 10 * blockSize)
					{
						bossBulletSpeedY[0] = bossBulletSpeedY[0] * -1;
					}
					if (bossBullet[1].y + bossBullet[1].r == 17 * blockSize)
					{
						bossBulletSpeedY[1] = bossBulletSpeedY[1] * -1;
					}
					else if (bossBullet[1].y == 7 * blockSize)
					{
						bossBulletSpeedY[1] = bossBulletSpeedY[1] * -1;
					}
					if (bossBullet[2].y + bossBullet[2].r == 17 * blockSize)
					{
						bossBulletSpeedY[2] = bossBulletSpeedY[2] * -1;
					}
					else if (bossBullet[2].y == 10 * blockSize)
					{
						bossBulletSpeedY[2] = bossBulletSpeedY[2] * -1;
					}
				}
			}

			for (int i = 0; i < enemyNum; i++)
			{
				if (bullet[i].x<player.x+player.r&&player.x-player.r<bullet[i].x+bullet[i].r)
				{
					if (bullet[i].y < player.y + player.r && player.y < bullet[i].y + bullet[i].r)
					{
						hitFlag[i] = 1;
						if (hitFlag[i] == 1)
						{
							if (noDamageTimer == 0)
							{
								playerHp = playerHp - bulletDamage;
							}
							noDamageTimer++;
							if (noDamageTimer == 30)
							{
								noDamageTimer = 0;
								hitFlag[i] = 0;
							}
						}
					}
				}
			}

			if (box_collision(sword.x, sword.y, sword.r, boss.x, boss.y, boss.r))
			{
				bossHitFlag = 1;
				if (bossHitFlag == 1)
				{
					bossHp--;
					hitTimer++;
					if (hitTimer > 20)
					{
						hitTimer = 0;
						bossHitFlag = 0;
					}
				}
			}
			if (fors.x < player.x + player.r && player.x < fors.x + fors.r)
			{
				if (fors.y < player.y + player.r && player.y < fors.y + fors.r)
				{
					scene = 2;
				}
			}
		}

		// �`�揈��
		if (scene == 0)
		{
			DrawGraph(0, 0, title, TRUE);
		}
		if (scene == 1)
		{
			for (int y = 0; y < mapSizeY; y++)
			{
				for (int x = 0; x < mapSizeX; x++)
				{
					if (map[y][x] == NONE)
					{
						DrawGraph(x * blockSize, y * blockSize, tile, TRUE);
					}
					if (map[y][x] == BLOCK)
					{
						DrawGraph(x * blockSize, y * blockSize, block, TRUE);
					}
					if (map[y][x] == WALL)
					{
						DrawGraph(x * blockSize, y * blockSize, wall, TRUE);
					}
					/*DrawLine(x * blockSize, 0, x * blockSize, end.y, cr, TRUE);
					DrawLine(0, y * blockSize, end.x, y * blockSize, cr, TRUE);*/
				}
			}

			//DrawBox(player.x - player.r, player.y - player.r, player.x + player.r, player.y + player.r, cr, TRUE);

			DrawGraph(player.x - player.r, player.y - player.r, GHandle[i], TRUE);

			if (keys[KEY_INPUT_UP] == 1)
			{
				GHandle[i] = GHandle1[i];
			}
			if (keys[KEY_INPUT_DOWN] == 1)
			{
				GHandle[i] = GHandle2[i];
			}
			if (keys[KEY_INPUT_LEFT] == 1)
			{
				GHandle[i] = GHandle3[i];
			}
			if (keys[KEY_INPUT_RIGHT] == 1)
			{
				GHandle[i] = GHandle4[i];
			}

			if (keys[KEY_INPUT_SPACE] == 1)
			{
				if (GHandle[i] == GHandle1[i])
				{
					DrawGraph(player.x - player.r, player.y - player.r * 3, attackUp, TRUE);
				}
				else if (GHandle[i] == GHandle2[i])
				{
					DrawGraph(player.x - player.r, player.y - player.r, attackDown, TRUE);
				}
				else if (GHandle[i] == GHandle3[i])
				{
					DrawGraph(player.x - player.r * 3, player.y - player.r, attackLeft, TRUE);
				}
				else if (GHandle[i] == GHandle4[i])
				{
					DrawGraph(player.x - player.r, player.y - player.r, attackRight, TRUE);
				}
			}

			for (int i = 0; i < enemyNum; i++)
			{
				if (enemy[i].hp == 1)
				{
					DrawGraph(bullet[i].x, bullet[i].y, enemyBullet, TRUE);
					if (i < 5)
					{
						if (i == 0)
						{
							DrawGraph(enemy[i].x, enemy[i].y, enemy1Down, TRUE);
						}
						else if (i == 1)
						{
							DrawGraph(enemy[i].x, enemy[i].y, enemy1Right, TRUE);
						}
						else if (i == 2)
						{
							DrawGraph(enemy[i].x, enemy[i].y, enemy1Left, TRUE);
						}
						else
						{
							DrawGraph(enemy[i].x, enemy[i].y, enemy1, TRUE);
						}
					}
					else if (i == 5)
					{
						DrawGraph(enemy[i].x, enemy[i].y, enemy2Left, TRUE);
					}
					else if (i == 6)
					{
						DrawGraph(enemy[i].x, enemy[i].y, enemy2, TRUE);
					}
					else if (i == 7)
					{
						DrawGraph(enemy[i].x, enemy[i].y, enemy2Right, TRUE);
					}
				}
				else if (enemy[i].hp <= 0)
				{
					DrawGraph(enemy[i].x, enemy[i].y, enemyDeath, TRUE);
				}
			}

			if (playerHp == 3)
			{
				DrawGraph(10, 0, playerHp3, TRUE);
			}
			else if (playerHp == 2)
			{
				DrawGraph(10, 0, playerHp2, TRUE);
			}
			else if (playerHp == 1)
			{
				DrawGraph(10, 0, playerHp1, TRUE);
			}
			else if (playerHp == 0)
			{
				DrawGraph(10, 0, playerHp0, TRUE);
			}

			if (bossHp > 0)
			{
				for (int i = 0; i < bossBulletNum; i++ && bossHp > 0)
				{
					DrawGraph(bossBullet[i].x, bossBullet[i].y, texBossBullet, TRUE);
				}
				if (bossHitFlag == 0)
				{
					DrawGraph(boss.x, boss.y, boss1, TRUE);
				}
				else if (bossHitFlag == 1)
				{
					DrawGraph(boss.x, boss.y, boss2, TRUE);
				}
			}

			//DrawBox(bullet[0].x, bullet[0].y, bullet[0].x + bullet[0].r, bullet[0].y + bullet[0].r, cr, FALSE);
			DrawGraph(fors.x - 10, fors.y - 10, texFors, TRUE);
		}
		if (scene == 2)
		{
			DrawGraph(0, 0, end1, TRUE);
		}
		//DrawBox(fors.x, fors.y, fors.x + fors.r, fors.y + fors.r, cr, FALSE);

		//DrawBox(sword.x, sword.y, sword.x + sword.r, sword.y + sword.r, cr, TRUE);

		//---------  �����܂łɃv���O�������L�q  ---------//
		// (�_�u���o�b�t�@)����
		ScreenFlip();

		// 20�~���b�ҋ@(�^��60FPS)
		WaitTimer(20);

		// Windows�V�X�e�����炭�������������
		if (ProcessMessage() == -1) {
			break;
		}

		// ESC�L�[�������ꂽ�烋�[�v���甲����
		if (CheckHitKey(KEY_INPUT_ESCAPE) == 1) {
			break;
		}
	}
	DeleteGraph(boss1);
	DeleteGraph(boss2);
	DeleteGraph(attackUp);
	DeleteGraph(attackDown);
	DeleteGraph(attackLeft);
	DeleteGraph(attackRight);
	DeleteGraph(playerHp3);
	DeleteGraph(playerHp2);
	DeleteGraph(playerHp1);
	DeleteGraph(playerHp0);
	DeleteGraph(enemy1);
	DeleteGraph(enemy1Down);
	DeleteGraph(enemy1Right);
	DeleteGraph(enemy1Left);
	DeleteGraph(enemy2);
	DeleteGraph(enemy2Left);
	DeleteGraph(enemy2Right);
	DeleteGraph(enemyDeath);
	DeleteGraph(enemyBullet);
	DeleteGraph(texBossBullet);
	DeleteGraph(texFors);
	DeleteGraph(title);
	DeleteGraph(end1);
	for (i = 0; i < 2; i++)
	{
		DeleteGraph(GHandle[i]);
	}
	for (i = 0; i < 2; i++)
	{
		DeleteGraph(GHandle1[i]);
	}
	for (i = 0; i < 2; i++)
	{
		DeleteGraph(GHandle2[i]);
	}
	for (i = 0; i < 2; i++)
	{
		DeleteGraph(GHandle3[i]);
	}
	for (i = 0; i < 2; i++)
	{
		DeleteGraph(GHandle4[i]);
	}

	// Dx���C�u�����I������
	DxLib_End();

	// ����I��
	return 0;
}
