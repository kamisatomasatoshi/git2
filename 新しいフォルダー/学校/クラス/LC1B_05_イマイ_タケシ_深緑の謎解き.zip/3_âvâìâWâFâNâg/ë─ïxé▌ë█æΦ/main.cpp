#include "DxLib.h"

#pragma region //�����l
// �E�B���h�E�̃^�C�g���ɕ\�����镶����
const char TITLE[] = "LC1B_06_�C�}�C�^�P�V:�[�΂̓����";

// �E�B���h�E����
const int WIN_WIDTH = 1600;

// �E�B���h�E�c��
const int WIN_HEIGHT = 960;
#pragma endregion

int WINAPI WinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ LPSTR lpCmdLine,
	_In_ int nCmdShow) {
	// �E�B���h�E���[�h�ɐݒ�
	ChangeWindowMode(TRUE);

	// �E�B���h�E�T�C�Y���蓮�ł͕ύX�������A
	// ���E�B���h�E�T�C�Y�ɍ��킹�Ċg��ł��Ȃ��悤�ɂ���
	SetWindowSizeChangeEnableFlag(FALSE, FALSE);

	// �^�C�g����ύX
	SetMainWindowText(TITLE);

	// ��ʃT�C�Y�̍ő�T�C�Y�A�J���[�r�b�g����ݒ�(���j�^�[�̉𑜓x�ɍ��킹��)
	SetGraphMode(WIN_WIDTH, WIN_HEIGHT, 32);

	// ��ʃT�C�Y��ݒ�(�𑜓x�Ƃ̔䗦�Őݒ�)
	SetWindowSizeExtendRate(1.0);

	// ��ʂ̔w�i�F��ݒ肷��
	SetBackgroundColor(0x00, 0x00, 0x00);

	// DXlib�̏�����
	if (DxLib_Init() == -1) { return -1; }

	// (�_�u���o�b�t�@)�`���O���t�B�b�N�̈�͗��ʂ��w��
	SetDrawScreen(DX_SCREEN_BACK);

	// �摜�Ȃǂ̃��\�[�X�f�[�^�̕ϐ��錾�Ɠǂݍ���


	// �Q�[�����[�v�Ŏg���ϐ��̐錾

	int sence = 0;

	//�v���C���[�̐���
	int isplFace2Left = 0;
	int moveRight = 0;
	int moveLeft = 0;
	int jump = 0;
	int action = 0;
	int menucontrol = 0;
	int timeleap = 0;
	int timeleapCT = 0;
	int isplFloat = 0;
	int message = 0;
	int menu = 0;
	int menuselect = 0;
	int menudetermine = 0;
	int up = 0;
	int down = 0;
	int gameEnd = 0;
	int loadStage = 1;

	int isleverWhiteOn = { 0 };
	int isleverRedOn = { 0 };
	int isleverBlueOn = { 0 };
	int leverBlueTimer = { 0 };

	int plposX = 160;
	int plposY = 960 - 32 - 64;
	int ploldposX[250] = { 0 };
	int ploldposY[250] = { 0 };
	int plradius = 64;

	int plSpeed = 8;
	int plVerocityY = 0;
	int plJumpInitialVerocity = 20;
	int gravityAcceralation = 1;

	int plpointUpperRightX = 0;
	int plpointUpperRightY = 0;
	int plpointLowerRightX = 0;
	int plpointLowerRightY = 0;
	int plpointUpperLeftX = 0;
	int plpointUpperLeftY = 0;
	int plpointLowerLeftX = 0;
	int plpointLowerLeftY = 0;

	//�X�e�[�W
	int stage = 0;

	//�}�b�v�`�b�v
	int map[30][50];

	//�摜�t�@�C��
	int a = LoadGraph("laz_idle_R.png");
	int lazIdelR[12];
	LoadDivGraph("laz_idle_R.png", 12, 12, 1, 128, 128, lazIdelR);
	int lazIdelL[12];
	LoadDivGraph("laz_idle_L.png", 12, 12, 1, 128, 128, lazIdelL);
	int lazWalkR[4];
	LoadDivGraph("laz_walk_R.png", 4, 4, 1, 128, 128, lazWalkR);
	int lazWalkL[4];
	LoadDivGraph("laz_walk_L.png", 4, 4, 1, 128, 128, lazWalkL);
	int lazJumpR[2];
	LoadDivGraph("laz_jump_R.png", 2, 2, 1, 128, 128, lazJumpR);
	int lazJumpL[2];
	LoadDivGraph("laz_jump_L.png", 2, 2, 1, 128, 128, lazJumpL);
	int lazFallR[2];
	LoadDivGraph("laz_fall_R.png", 2, 2, 1, 128, 128, lazFallR);
	int lazFallL[2];
	LoadDivGraph("laz_fall_L.png", 2, 2, 1, 128, 128, lazFallL);
	int haikei = LoadGraph("haikei.png");
	int mapchip = LoadGraph("mapchip.png");
	int ibaratate = LoadGraph("ibara_tate.png");
	int ibarayoko = LoadGraph("ibara_yoko.png");
	int kannbann = LoadGraph("kannbann.png");
	int usuguro = LoadGraph("usuguro.png");
	int leverWhite[2];
	LoadDivGraph("lever.png", 2, 2, 1, 64, 64, leverWhite);
	int leverRed[2];
	LoadDivGraph("lever_red.png", 2, 2, 1, 64, 64, leverRed);
	int leverBlue[2];
	LoadDivGraph("lever_blue.png", 2, 2, 1, 64, 64, leverBlue);
	int logo = LoadGraph("title.png");
	int pressEnterToStart = LoadGraph("press_enter_to_start.png");

	int lazAnimTimer = 0;
	int idlenum = 0;
	int walknum = 0;
	int floatnum = 0;

	//BGM
	int bgm = LoadSoundMem("BGM.mp3");

	// �ŐV�̃L�[�{�[�h���p
	char keys[256] = { 0 };

	// 1���[�v(�t���[��)�O�̃L�[�{�[�h���
	char oldkeys[256] = { 0 };

	// �Q�[�����[�v
	while (true) {
		// �ŐV�̃L�[�{�[�h��񂾂������̂�1�t���[���O�̃L�[�{�[�h���Ƃ��ĕۑ�
		for (int i = 0; i < 256; ++i) {
			oldkeys[i] = keys[i];
		}

		// �ŐV�̃L�[�{�[�h�����擾
		GetHitKeyStateAll(keys);

		// ��ʃN���A
		ClearDrawScreen();
		//---------  ��������v���O�������L�q  ----------//

		// �X�V����
		//�L�[�ݒ�

		if (message == 0 && menu == 0) {
			moveRight = keys[KEY_INPUT_D];
			moveLeft = keys[KEY_INPUT_A];
			jump = keys[KEY_INPUT_SPACE] == 1 && oldkeys[KEY_INPUT_SPACE] == 0;
			timeleap = keys[KEY_INPUT_Q] == 1 && oldkeys[KEY_INPUT_Q] == 0;
		}
		action = keys[KEY_INPUT_E] == 1 && oldkeys[KEY_INPUT_E] == 0;
		menucontrol = keys[KEY_INPUT_ESCAPE] == 1 && oldkeys[KEY_INPUT_ESCAPE] == 0;
		up = keys[KEY_INPUT_W] == 1 && oldkeys[KEY_INPUT_W] == 0;
		down = keys[KEY_INPUT_S] == 1 && oldkeys[KEY_INPUT_S] == 0;
		menudetermine = keys[KEY_INPUT_RETURN] == 1 && oldkeys[KEY_INPUT_RETURN] == 0;

		if (sence == 0) {
			if (menudetermine == 1) {
				stage = 1;
				sence++;
				loadStage = 1;
			}
		}

		if (sence == 1) {
			//�}�b�v�`�b�v 0:�����Ȃ�.1:��,�n��.2:��c����.3�����.-1:�Ŕ�.-2:���o�[��.-3:���o�[��.-4:���o�[��.-5:���ɐi��//
			//�X�e�[�W�̃��[�h
			if (loadStage == 1) {
				for (int i = 0; i < 30; i++) {
					for (int j = 0; j < 50; j++) {
						map[i][j] = 0;
						if (stage == 1) {
							map[0][j] = 1;
							map[1][j] = 1;
							map[i][0] = 1;
							map[i][1] = 1;
							map[29][j] = 1;
							map[i][48] = 1;
							map[i][49] = 1;
							if (j == 48) {
								if (24 <= i && i <= 28) {
									map[i][j] = 2;
								}
							}
							if (j == 49) {
								if (24 <= i && i <= 28) {
									map[i][j] = -5;
								}
							}
							map[27][5] = -1;
							map[23][25] = -2;
							if (24 < i) {
								if (15 < j && j < 35) {
									map[i][j] = 1;
								}
							}
						}
						if (stage == 2) {
							for (int i = 0; i < 30; i++) {
								for (int j = 0; j < 50; j++) {
									map[i][j] = 0;
									map[0][j] = 1;
									map[1][j] = 1;
									map[i][0] = 1;
									map[i][1] = 1;
									map[29][j] = 1;
									map[i][48] = 1;
									map[i][49] = 1;
									if (j == 48) {
										if (24 <= i && i <= 28) {
											map[i][j] = 2;
										}
									}
									if (j == 49) {
										if (24 <= i && i <= 28) {
											map[i][j] = -5;
										}
									}
									map[27][5] = -1;
									map[27][25] = -3;
									if (23 < i) {
										if (15 < j && j < 20) {
											map[i][j] = 1;
										}
										if (30 < j && j < 35) {
											map[i][j] = 1;
										}
									}
								}
							}
						}
						if (stage == 3) {
							map[i][j] = 0;
							map[0][j] = 1;
							map[1][j] = 1;
							map[i][0] = 1;
							map[i][1] = 1;
							map[29][j] = 1;
							map[i][48] = 1;
							map[i][49] = 1;
							if (j == 48) {
								if (24 <= i && i <= 28) {
									map[i][j] = 2;
								}
							}
							if (j == 49) {
								if (24 <= i && i <= 28) {
									map[i][j] = -5;
								}
							}
							map[27][5] = -1;
							map[10][45] = -4;
							if (11 < i && i < 13) {
								if (10 < j) {
									map[i][j] = 1;
								}
							}
							if (17 < i && i < 19) {
								if (0 < j && j < 10) {
									map[i][j] = 1;
								}
							}
							if (23 < i) {
								if (10 < j && j < 20) {
									map[i][j] = 1;
								}
							}
						}
						if (stage == 4) {
							map[0][j] = 1;
							map[1][j] = 1;
							map[i][0] = 1;
							map[i][1] = 1;
							map[29][j] = 1;
							map[i][48] = 1;
							map[i][49] = 1;
							if (8 <= i && i <= 12) {
								if (j < 10) {
									map[i][j] = 1;
								}
							}
							if (20 <= i && i <= 23) {
								if (40 < j) {
									map[i][j] = 1;
								}
							}
							if (25 < i) {
								if (30 < j && j < 35) {
									map[i][j] = 1;
								}
							}
							if (10 < i && i < 16) {
								if (16 < j && j < 20) {
									map[i][j] = 1;
								}
							}
							if (15 < i && i < 21) {
								if (16 < j && j < 31) {
									map[i][j] = 1;
								}
							}
							if (j == 48) {
								if (24 <= i && i <= 28) {
									map[i][j] = 2;
								}
							}
							if (j == 49) {
								if (24 <= i && i <= 28) {
									map[i][j] = -5;
								}
							}
							map[27][5] = -1;
							map[6][5] = -2;
							map[18][42] = -3;
						}
						if (stage == 5) {
							map[0][j] = 1;
							map[1][j] = 1;
							map[i][0] = 1;
							map[i][1] = 1;
							map[29][j] = 1;
							map[i][48] = 1;
							map[i][49] = 1;
							if (j == 48) {
								if (24 <= i && i <= 28) {
									map[i][j] = 2;
								}
							}
							if (j == 49) {
								if (24 <= i && i <= 28) {
									map[i][j] = -5;
								}
							}
							if (i == 8) {
								if (40 < j) {
									map[i][j] = 1;
								}
							}
							if (i == 12) {
								if (15 < j && j < 35) {
									map[i][j] = 1;
								}
							}
							if (i == 16) {
								if (j < 10) {
									map[i][j] = 1;
								}
							}
							if (i == 20) {
								if (15 < j && j < 35) {
									map[i][j] = 1;
								}
							}
							if (i == 24) {
								if (40 < j) {
									map[i][j] = 1;
								}
							}
							map[27][5] = -1;
							map[6][45] = -2;
							map[27][10] = -4;
						}
						if (stage == 6) {
							map[0][j] = 1;
							map[1][j] = 1;
							map[i][0] = 1;
							map[i][1] = 1;
							map[29][j] = 1;
							map[i][48] = 1;
							map[i][49] = 1;

							if (i == 24) {
								if (j < 5) {
									map[i][j] = 1;
								}
							}
							if (20 <= i && i < 25) {
								if (10 <= j && j <= 15) {
									map[i][j] = 1;
								}
							}
							if (9 <= i && i < 15) {
								if (j <= 20) {
									map[i][j] = 1;
								}
							}
							if (20 <= i && i < 25) {
								if (20 <= j && j <= 25) {
									map[i][j] = 1;
								}
							}
							if (9 <= i && i < 15) {
								if (25 <= j) {
									map[i][j] = 1;
								}
							}
							if (20 <= i && i < 25) {
								if (30 <= j && j <= 35) {
									map[i][j] = 1;
								}
							}

							if (j == 48) {
								if (24 <= i && i <= 28) {
									map[i][j] = 2;
								}
							}
							if (j == 49) {
								if (24 <= i && i <= 28) {
									map[i][j] = -5;
								}
							}
							map[27][5] = -1;
							map[7][5] = -2;
							map[7][30] = -3;
							map[18][12] = -3;
							map[7][45] = -4;
							map[18][32] = -4;
						}
						if (stage == 7) {
							map[0][j] = 1;
							map[1][j] = 1;
							map[i][0] = 1;
							map[i][1] = 1;
							map[29][j] = 1;
							map[i][48] = 1;
							map[i][49] = 1;

							if (6 < i) {
								if (42 < j && j < 45) {
									map[i][j] = 1;
								}
							}
							if (6 < i && i < 11) {
								if (35 < j && j < 40) {
									map[i][j] = 1;
								}
							}
							if (6 < i && i < 11) {
								if (j < 6) {
									map[i][j] = 1;
								}
							}
							if (15 < i && i < 20) {
								if (38 < j && j < 43) {
									map[i][j] = 1;
								}
							}
							if (15 < i && i < 20) {
								if (j < 6) {
									map[i][j] = 1;
								}
							}

							if (15 < i && i < 20) {
								if (20 < j && j < 34) {
									map[i][j] = 1;
								}
							}

							if (6 < i && i < 11) {
								if (21 < j && j < 30) {
									map[i][j] = 1;
								}
							}

							if (6 < i && i < 20) {
								if (10 < j && j < 15) {
									map[i][j] = 1;
								}
							}
							if (i == 12) {
								if (14 < j && j < 18) {
									map[i][j] = 1;
								}
							}
							if (24 < i) {
								if (33 < j && j < 39) {
									map[i][j] = 1;
								}
							}


							if (j == 48) {
								if (24 <= i && i <= 28) {
									map[i][j] = 2;
								}
							}
							if (j == 49) {
								if (24 <= i && i <= 28) {
									map[i][j] = -5;
								}
							}
							map[27][5] = -1;
							map[5][37] = -2;
							map[27][40] = -3;
							map[14][3] = -3;
							map[14][25] = -3;
							map[5][3] = -4;
						}
					}
				}
				for (int i = 249; 0 <= i; i--) {
					ploldposX[i] = 0;
					ploldposY[i] = 0;
				}
				timeleapCT = 250;
				plposX = 160;
				plposY = 960 - 32 - 64;
				isleverWhiteOn = 0;
				isleverRedOn = 0;
				isleverBlueOn = 0;
				leverBlueTimer = 250;
				loadStage = 0;
			}
			//�v���C���[�̎l���̍��W���擾
			plpointUpperRightX = (plposX + plradius / 2 - 1) / 32;
			plpointUpperRightY = (plposY - plradius) / 32;
			plpointLowerRightX = (plposX + plradius / 2 - 1) / 32;
			plpointLowerRightY = (plposY + plradius - 1) / 32;
			plpointUpperLeftX = (plposX - plradius / 2) / 32;
			plpointUpperLeftY = (plposY - plradius) / 32;
			plpointLowerLeftX = (plposX - plradius / 2) / 32;
			plpointLowerLeftY = (plposY + plradius - 1) / 32;

			//�v���C���[�ƃ}�b�v�`�b�v�̓����蔻��//
			//��ɕǂ��������瓪���Ԃ���
			plpointUpperRightY = ((plposY - plVerocityY) - plradius) / 32;
			plpointUpperLeftY = ((plposY - plVerocityY) - plradius) / 32;
			if (1 <= map[plpointUpperRightY][plpointUpperRightX]) {
				plposY = plpointUpperRightY * 32 + 96;
				plVerocityY = 0;
			}
			else if (1 <= map[plpointUpperLeftY][plpointUpperLeftX]) {
				plposY = plpointUpperLeftY * 32 + 96;
				plVerocityY = 0;
			}

			//���ɒn�ʂ��Ȃ������痎������
			if (isplFloat == 0) {
				if (map[plpointLowerRightY + 1][plpointLowerRightX] <= 0 && map[plpointLowerLeftY + 1][plpointLowerLeftX] <= 0) {
					isplFloat = 1;
				}
			}

			//�󒆂ɂ���Ƃ��������Ēn�ʂŒ��n����
			if (isplFloat == 1) {
				plpointLowerRightY = ((plposY - plVerocityY) + plradius) / 32;
				plpointLowerLeftY = ((plposY - plVerocityY) + plradius) / 32;
				if (1 <= map[plpointLowerRightY][plpointLowerRightX]) {
					plposY = plpointLowerRightY * 32 - 64;
					isplFloat = 0;
					plVerocityY = 0;
				}
				else if (1 <= map[plpointLowerLeftY][plpointLowerLeftX]) {
					plposY = plpointLowerLeftY * 32 - 64;
					isplFloat = 0;
					plVerocityY = 0;
				}
				else {
					plposY -= plVerocityY;
					plVerocityY -= gravityAcceralation;
					if (plVerocityY <= -28) {
						plVerocityY = -28;
					}
				}
			}

			//���ɕǂ��Ȃ������獶�ɐi��
			if (moveLeft == 1) {
				plpointUpperLeftX = ((plposX - plSpeed) - plradius / 2) / 32;
				plpointLowerLeftX = ((plposX - plSpeed) - plradius / 2) / 32;
				if (1 <= map[plpointLowerLeftY][plpointLowerLeftX]) {
					plposX = ploldposX[0];
				}
				else if (1 <= map[plpointUpperLeftY][plpointUpperLeftX]) {
					plposX = ploldposX[0];
				}
				else {
					plposX -= 8;
					isplFace2Left = 1;
				}
			}

			//�E�ɕǂ��Ȃ�������E�ɐi��
			if (moveRight == 1) {
				plpointUpperRightX = ((plposX + plSpeed) + plradius / 2) / 32;
				plpointLowerRightX = ((plposX + plSpeed) + plradius / 2) / 32;
				if (1 <= map[plpointLowerRightY][plpointLowerRightX]) {
					plposX = ploldposX[0];
				}
				else if (1 <= map[plpointUpperRightY][plpointUpperRightX]) {
					plposX = ploldposX[0];
				}
				else {
					plposX += 8;
					isplFace2Left = 0;
				}
			}

			//�ܕb�O�̎����̈ʒu���L������
			for (int i = 249; 0 <= i; i--) {
				if (i == 0) {
					ploldposX[i] = plposX;
					ploldposY[i] = plposY;
				}
				else {
					ploldposX[i] = ploldposX[i - 1];
					ploldposY[i] = ploldposY[i - 1];
				}
			}

			//�ŔɐG��Ă��鎞�Ŕ𒲂ׂ�
			if (map[plposY / 32][plposX / 32] == -1) {
				if (action == 1) {
					if (message == 0) {
						message = 1;
					}
					else if (message == 1) {
						message = 0;
					}
				}
			}

			//���o�[�𒲂ׂ�
			if (map[plposY / 32][plposX / 32] == -2) {
				if (action == 1) {
					if (isleverWhiteOn == 0) {
						isleverWhiteOn = 1;
					}
					else if (isleverWhiteOn == 1) {
						isleverWhiteOn = 0;
					}
				}
			}
			if (map[plposY / 32][plposX / 32] == -3) {
				if (action == 1) {
					if (isleverRedOn == 0) {
						isleverRedOn = 1;
					}
					else if (isleverRedOn == 1) {
						isleverRedOn = 0;
					}
				}
			}
			if (map[plposY / 32][plposX / 32] == -4) {
				if (action == 1) {
					if (isleverBlueOn == 0) {
						isleverBlueOn = 1;
					}
				}
			}
			if (isleverBlueOn == 1) {
				leverBlueTimer--;
				if (leverBlueTimer <= 0) {
					isleverBlueOn = 0;
					leverBlueTimer = 250;
				}
			}


			//���o�[�ɂ��X�e�[�W�M�~�b�N�̐���
			for (int i = 0; i < 30; i++) {
				for (int j = 0; j < 50; j++) {
					if (stage == 1) {
						if (isleverWhiteOn == 0) {
							if (j == 48) {
								if (24 <= i && i <= 28) {
									map[i][j] = 2;
								}
							}
						}
						if (isleverWhiteOn == 1) {
							if (j == 48) {
								if (24 <= i && i <= 28) {
									map[i][j] = 0;
								}
							}
						}
					}
					if (stage == 2) {
						if (isleverRedOn == 0) {
							if (j == 48) {
								if (24 <= i && i <= 28) {
									map[i][j] = 2;
								}
							}
							if (i == 24) {
								if (20 <= j && j <= 30) {
									map[i][j] = 0;
								}
							}
						}
						if (isleverRedOn == 1) {
							if (j == 48) {
								if (24 <= i && i <= 28) {
									map[i][j] = 0;
								}
							}
							if (i == 24) {
								if (20 <= j && j <= 30) {
									map[i][j] = 3;
								}
							}
						}
					}
					if (stage == 3) {
						if (isleverBlueOn == 0) {
							if (j == 48) {
								if (24 <= i && i <= 28) {
									map[i][j] = 2;
								}
							}
						}
						if (isleverBlueOn == 1) {
							if (j == 48) {
								if (24 <= i && i <= 28) {
									map[i][j] = 0;
								}
							}
						}
					}
					if (stage == 4) {
						if (isleverWhiteOn == 0) {
							if (j == 48) {
								if (24 <= i && i <= 28) {
									map[i][j] = 2;
								}
							}
						}
						if (isleverWhiteOn == 1) {
							if (j == 48) {
								if (24 <= i && i <= 28) {
									map[i][j] = 0;
								}
							}
						}
						if (isleverRedOn == 0) {
							if (j == 45) {
								if (24 <= i && i <= 28) {
									map[i][j] = 2;
								}
							}
							if (i == 20) {
								if (31 <= j && j <= 40) {
									map[i][j] = 0;
								}
							}
							if (i == 11) {
								if (10 <= j && j <= 16) {
									map[i][j] = 0;
								}
							}
						}
						if (isleverRedOn == 1) {
							if (j == 45) {
								if (24 <= i && i <= 28) {
									map[i][j] = 0;
								}
							}
							if (i == 20) {
								if (31 <= j && j <= 40) {
									map[i][j] = 3;
								}
							}
							if (i == 11) {
								if (10 <= j && j <= 16) {
									map[i][j] = 3;
								}
							}
						}
					}
					if (stage == 5) {
						if (isleverWhiteOn == 0) {
							if (j == 48) {
								if (25 <= i && i <= 28) {
									map[i][j] = 2;
								}
							}
						}
						if (isleverWhiteOn == 1) {
							if (j == 48) {
								if (25 <= i && i <= 28) {
									map[i][j] = 0;
								}
							}
						}
						if (isleverBlueOn == 0) {
							if (j == 41) {
								if (2 <= i && i <= 7) {
									map[i][j] = 2;
								}
							}
						}
						if (isleverBlueOn == 1) {
							if (j == 41) {
								if (2 <= i && i <= 7) {
									map[i][j] = 0;
								}
							}
						}
					}
					if (stage == 6) {
						if (isleverWhiteOn == 0) {
							if (j == 48) {
								if (24 <= i && i <= 28) {
									map[i][j] = 2;
								}
							}
						}
						if (isleverWhiteOn == 1) {
							if (j == 48) {
								if (24 <= i && i <= 28) {
									map[i][j] = 0;
								}
							}
						}
						if (isleverRedOn == 0) {
							if (i == 20) {
								if (15 < j && j < 20 || 25 < j && j < 30) {
									map[i][j] = 3;
								}
							}
							if (i == 9) {
								if (20 < j && j < 25) {
									map[i][j] = 3;
								}
							}
							if (15 <= i && i < 20) {
								if (j == 15 || j == 20 || j == 25 || j == 30) {
									map[i][j] = 0;
								}
							}
							if (2 <= i && i < 9) {
								if (j == 15 || j == 35) {
									map[i][j] = 0;
								}
							}
						}
						if (isleverRedOn == 1) {
							if (i == 20) {
								if (15 < j && j < 20 || 25 < j && j < 30) {
									map[i][j] = 0;
								}
							}
							if (i == 9) {
								if (20 < j && j < 25) {
									map[i][j] = 0;
								}
							}
							if (15 <= i && i < 20) {
								if (j == 15 || j == 20 || j == 25 || j == 30) {
									map[i][j] = 2;
								}
							}
							if (2 <= i && i < 9) {
								if (j == 15 || j == 35) {
									map[i][j] = 2;
								}
							}
						}
						if (isleverBlueOn == 0) {
							if (i == 14) {
								if (20 < j && j < 25) {
									map[i][j] = 3;
								}
							}
						}
						if (isleverBlueOn == 1) {
							if (i == 14) {
								if (20 < j && j < 25) {
									map[i][j] = 0;
								}
							}
						}
					}
					if (stage == 7) {
						if (isleverWhiteOn == 0) {
							if (j == 48) {
								if (24 <= i && i <= 28) {
									map[i][j] = 2;
								}
							}
						}
						if (isleverWhiteOn == 1) {
							if (j == 48) {
								if (24 <= i && i <= 28) {
									map[i][j] = 0;
								}
							}
						}
						if (isleverRedOn == 0) {
							if (i == 19) {
								if (33 < j && j < 39) {
									map[i][j] = 3;
								}
							}
							if (i == 16) {
								if (5 < j && j < 11) {
									map[i][j] = 3;
								}
							}
							if (i == 10) {
								if (5 < j && j < 11) {
									map[i][j] = 3;
								}
							}
							if (i == 7) {
								if (14 < j && j < 22) {
									map[i][j] = 3;
								}
							}
							if (1 < i && i < 7) {
								if (j == 5) {
									map[i][j] = 0;
								}
							}
						}
						if (isleverRedOn == 1) {
							if (i == 19) {
								if (33 < j && j < 39) {
									map[i][j] = 0;
								}
							}
							if (i == 16) {
								if (5 < j && j < 11) {
									map[i][j] = 0;
								}
							}
							if (i == 10) {
								if (5 < j && j < 11) {
									map[i][j] = 0;
								}
							}
							if (i == 7) {
								if (14 < j && j < 22) {
									map[i][j] = 0;
								}
							}
							if (1 < i && i < 7) {
								if (j == 5) {
									map[i][j] = 2;
								}
							}
						}
						if (isleverBlueOn == 0) {
							if (i == 10) {
								if (39 < j && j < 43) {
									map[i][j] = 3;
								}
							}
						}
						if (isleverBlueOn == 1) {
							if (i == 10) {
								if (39 < j && j < 43) {
									map[i][j] = 0;
								}
							}
						}
					}
				}
			}

			//���̃X�e�[�W�ɐi��
			if (map[plpointLowerRightY][plpointLowerRightX] == -5 || map[plpointUpperRightY][plpointUpperRightX] == -5) {
				if (stage == 7) {
					sence++;
				}
				else {
					stage++;
					loadStage = 1;
				}
			}

			//�v���C���[�̃A�N�V����//
			//�n�ʂɂ���Ƃ��W�����v����
			if (isplFloat == 0) {
				if (jump == 1) {
					plVerocityY += plJumpInitialVerocity;
					isplFloat = 1;
				}
			}

			//�ܕb�O�̎����ɖ߂�
			if (timeleapCT <= 0) {
				if (timeleap == 1) {
					plposX = ploldposX[249];
					plposY = ploldposY[249];
					timeleapCT = 250;
					isplFloat = 1;
				}
			}
			//�^�C�����[�v�̃N�[���^�C�����v�Z����
			if (0 < timeleapCT) {
				timeleapCT--;
			}

			//�Ŕ̃��b�Z�[�W���\������Ă��Ȃ��Ƃ����j���[���J����������肷��
			if (message == 0) {
				if (menucontrol == 1) {
					if (menu == 0) {
						menu = 1;
						menuselect = 0;
					}
					else if (menu == 1) {
						menu = 0;
					}
				}
			}

			//���j���[�̐���
			if (menu == 1) {
				if (menudetermine == 1) {
					if (menuselect == 0) {
						menu = 0;
					}
					else if (menuselect == 1) {
						loadStage = 1;
						menu = 0;
					}
					else if (menuselect == 2) {
						gameEnd = 1;
					}
				}
				if (0 < menuselect) {
					if (up == 1) {
						menuselect -= 1;
					}
				}
				if (menuselect < 2) {
					if (down == 1) {
						menuselect += 1;
					}
				}
			}

			//�A�j���[�V�����̍Đ�//
			if (lazAnimTimer <= 0) {
				//��������
				if (idlenum <= 12) {
					idlenum++;
					if (idlenum == 12) {
						idlenum = 0;
					}
				}

				//����
				if (walknum <= 4) {
					walknum++;
					if (walknum == 4) {
						walknum = 0;
					}
				}

				//��
				if (floatnum <= 2) {
					floatnum++;
					if (floatnum == 2) {
						floatnum = 0;
					}
				}
				lazAnimTimer = 5;
			}
			else {
				lazAnimTimer--;
			}
		}

		if (sence == 2) {
			if (menudetermine == 1) {
				sence = 0;
			}
		}
		// �`�揈��
#pragma region //�O���t�B�b�N
		DrawGraph(0, 0, haikei, true);
		if (sence == 0) {
			DrawGraph(200, 150, logo, true);
			DrawGraph(500, 800, pressEnterToStart, true);
		}
		if (sence == 1) {
			for (int i = 0; i < 30; i++) {
				for (int j = 0; j < 50; j++) {
					if (map[i][j] == 1) {
						DrawGraph(j * 32, i * 32, mapchip, true);
					}
					if (map[i][j] == 2) {
						DrawGraph(j * 32, i * 32, ibaratate, true);
					}
					if (map[i][j] == 3) {
						DrawGraph(j * 32, i * 32, ibarayoko, true);
					}
					if (map[i][j] == -1) {
						DrawGraph(j * 32, i * 32, kannbann, true);
					}
					if (map[i][j] == -2) {
						if (isleverWhiteOn == 0) {
							DrawGraph(j * 32, i * 32, leverWhite[0], true);
						}
						if (isleverWhiteOn == 1) {
							DrawGraph(j * 32, i * 32, leverWhite[1], true);
						}
					}
					if (map[i][j] == -3) {
						if (isleverRedOn == 0) {
							DrawGraph(j * 32, i * 32, leverRed[0], true);
						}
						if (isleverRedOn == 1) {
							DrawGraph(j * 32, i * 32, leverRed[1], true);
						}
					}
					if (map[i][j] == -4) {
						if (isleverBlueOn == 0) {
							DrawGraph(j * 32, i * 32, leverBlue[0], true);
						}
						if (isleverBlueOn == 1) {
							DrawGraph(j * 32, i * 32, leverBlue[1], true);
						}
					}
				}
			}
			if (isplFace2Left == 1) {
				if (isplFloat == 1) {
					if (0 < plVerocityY) {
						DrawGraph(plposX - plradius, plposY - plradius, lazJumpL[floatnum], true);
					}
					else {
						DrawGraph(plposX - plradius, plposY - plradius, lazFallL[floatnum], true);
					}
				}
				else if (moveLeft == 1) {
					DrawGraph(plposX - plradius, plposY - plradius, lazWalkL[walknum], true);
				}
				else {
					DrawGraph(plposX - plradius, plposY - plradius, lazIdelL[idlenum], true);
				}
			}
			else {
				if (isplFloat == 1) {
					if (0 < plVerocityY) {
						DrawGraph(plposX - plradius, plposY - plradius, lazJumpR[floatnum], true);
					}
					else {
						DrawGraph(plposX - plradius, plposY - plradius, lazFallR[floatnum], true);
					}
				}
				else if (moveRight == 1) {
					DrawGraph(plposX - plradius, plposY - plradius, lazWalkR[walknum], true);
				}
				else {
					DrawGraph(plposX - plradius, plposY - plradius, lazIdelR[idlenum], true);
				}
			}

			if (message == 1 || menu == 1) {
				DrawGraph(0, 0, usuguro, true);
			}

			if (menu == 0) {
				if (message == 0) {
					if (map[plposY / 32][plposX / 32] == -1) {
						DrawFormatString(plposX - plradius, plposY - plradius - 16, GetColor(255, 255, 255), "�ǂ�:E�L�[");
					}
				}
				if (message == 1) {
					if (stage == 1) {
						DrawFormatString(100, 100, GetColor(255, 255, 255), "������@");
						DrawFormatString(200, 120, GetColor(255, 255, 255), "�E:D�L�[");
						DrawFormatString(200, 140, GetColor(255, 255, 255), "��:A�L�[");
						DrawFormatString(200, 160, GetColor(255, 255, 255), "�W�����v:SPACE�L�[");
						DrawFormatString(200, 180, GetColor(255, 255, 255), "�A�N�V����:E�L�[");
						DrawFormatString(200, 200, GetColor(255, 255, 255), "5�b�O�̎����ɖ߂�(�N�[���^�C����5�b):Q�L�[");
						DrawFormatString(200, 220, GetColor(255, 255, 255), "���j���[���J��:ESC�L�[");
						DrawFormatString(100, 260, GetColor(255, 255, 255), "�q���g");
						DrawFormatString(200, 280, GetColor(255, 255, 255), "���ケ�̊Ŕɂ͍U���̃q���g���������");
						DrawFormatString(200, 300, GetColor(255, 255, 255), "�܂��̓X�e�[�W�����̃��o�[�𒲂ׂĐ�ւ�����");
						DrawFormatString(500, 400, GetColor(255, 255, 255), "E�L�[�ŕ���");
					}
					if (stage == 2) {
						DrawFormatString(100, 100, GetColor(255, 255, 255), "�q���g");
						DrawFormatString(200, 120, GetColor(255, 255, 255), "�Ԃ̃��o�[�͂ǂ������J�������ɂǂ�����߂�");
						DrawFormatString(200, 140, GetColor(255, 255, 255), "���������Ȃ��͂��̒����甲���o�����Ƃ��o����");
						DrawFormatString(500, 240, GetColor(255, 255, 255), "E�L�[�ŕ���");
					}
					if (stage == 3) {
						DrawFormatString(100, 100, GetColor(255, 255, 255), "�q���g");
						DrawFormatString(200, 120, GetColor(255, 255, 255), "�̃��o�[�͎��Ԍo�߂ŏ���Ɍ��ɖ߂�");
						DrawFormatString(200, 140, GetColor(255, 255, 255), "���Ԃ�����Ȃ��Ȃ�ړ�������Z������΂���");
						DrawFormatString(500, 240, GetColor(255, 255, 255), "E�L�[�ŕ���");
					}
					if (stage == 4) {
						DrawFormatString(100, 100, GetColor(255, 255, 255), "�q���g");
						DrawFormatString(200, 120, GetColor(255, 255, 255), "�����J���Ȃ��Ȃ痧���~�܂邱�Ƃ��d�v");
						DrawFormatString(500, 220, GetColor(255, 255, 255), "E�L�[�ŕ���");
					}
					if (stage == 5) {
						DrawFormatString(100, 100, GetColor(255, 255, 255), "�q���g");
						DrawFormatString(200, 120, GetColor(255, 255, 255), "�ǂ�����Ȃ�͂��H");
						DrawFormatString(500, 220, GetColor(255, 255, 255), "E�L�[�ŕ���");
					}
					if (stage == 6) {
						DrawFormatString(100, 100, GetColor(255, 255, 255), "�q���g");
						DrawFormatString(200, 120, GetColor(255, 255, 255), "5�b�O�͂ǂ��ɂ���?");
						DrawFormatString(500, 220, GetColor(255, 255, 255), "E�L�[�ŕ���");
					}
					if (stage == 7) {
						DrawFormatString(200, 100, GetColor(255, 255, 255), "�����܂ŉ��������Ȃ��Ȃ�����邾�낤");
						DrawFormatString(200, 120, GetColor(255, 255, 255), "�q���g�͖�����");
						DrawFormatString(500, 220, GetColor(255, 255, 255), "E�L�[�ŕ���");
					}
				}
			}
			if (menu == 1) {
				DrawFormatString(100, 100, GetColor(255, 255, 255), "���j���[");
				if (menuselect == 0) {
					DrawFormatString(200, 120, GetColor(255, 255, 0), "�Q�[���v���C�ɖ߂�");
					DrawFormatString(200, 160, GetColor(255, 255, 255), "�X�e�[�W����蒼��");
					DrawFormatString(200, 200, GetColor(255, 255, 255), "�Q�[�����I���");
				}
				if (menuselect == 1) {
					DrawFormatString(200, 120, GetColor(255, 255, 255), "�Q�[���v���C�ɖ߂�");
					DrawFormatString(200, 160, GetColor(255, 255, 0), "�X�e�[�W����蒼��");
					DrawFormatString(200, 200, GetColor(255, 255, 255), "�Q�[�����I���");
				}
				if (menuselect == 2) {
					DrawFormatString(200, 120, GetColor(255, 255, 255), "�Q�[���v���C�ɖ߂�");
					DrawFormatString(200, 160, GetColor(255, 255, 255), "�X�e�[�W����蒼��");
					DrawFormatString(200, 200, GetColor(255, 255, 0), "�Q�[�����I���");
				}
				DrawFormatString(450, 300, GetColor(255, 255, 255), "��:W�L�[,��:S�L�[,����:ENTER�L�[");
			}
			if (map[plposY / 32][plposX / 32] == -2 || map[plposY / 32][plposX / 32] == -3 || map[plposY / 32][plposX / 32] == -4) {
				DrawFormatString(plposX - plradius, plposY - plradius - 16, GetColor(255, 255, 255), "���ׂ�:E�L�[");
			}
		}
		if (sence == 2) {
			DrawGraph(0, 0, usuguro, true);
			DrawFormatString(610, 400, GetColor(255, 255, 255), "�S�X�e�[�W�N���A!���߂łƂ��������܂�!");
			DrawFormatString(660, 500, GetColor(255, 255, 255), "ENTER�L�[�Ń^�C�g���ɖ߂�");
		}
#pragma endregion
		PlaySoundMem(bgm, DX_PLAYTYPE_LOOP, false);
		//---------  �����܂łɃv���O�������L�q  ---------//
		// (�_�u���o�b�t�@)����
		ScreenFlip();

		// 20�~���b�ҋ@(�^��60FPS)
		WaitTimer(20);

		// Windows�V�X�e�����炭�������������
		if (ProcessMessage() == -1) {
			break;
		}

		// ESC�L�[�������ꂽ�烋�[�v���甲����
		if (gameEnd == 1) {
			break;
		}
	}
	// Dx���C�u�����I������
	DxLib_End();

	// ����I��
	return 0;
}
