#include "DxLib.h"
#include <cmath>
#include <iostream>


//�v���C���[��
float PLAYER_G = 0.3F;                         // �v���C���[�Ɋ|����d�͉����x
#define PLAYER_JUMP_POWER       (9.0F)                         // �v���C���[�̃W�����v��
#define PLAYER_SPEED            (5.0F)                         // �v���C���[�̈ړ��X�s�[�h
#define PLAYER_SIZE        (57)                           // �v���C���[�̃T�C�Y
float PlayerCoreX = 90;
float PlayerCoreY = 860;            // �v���C���[�̍��W(���S���W)
float PlayerDownSpeed;            // �v���C���[�̗������x
char PlayerJumpFlag;           // �v���C���[���W�����v�����A�̃t���O
  //�X���C����
#define SLIME_G                (0.3F)                         
#define SLIME_JUMP_POWER       (9.0F)                         
#define SLIME_SPEED            (1.0F)                         
#define SLIME_SIZE        (51)                           

float SlimeADownSpeed[5];
char SlimeAJumpFlag[5];
float SlimeBDownSpeed[5];
char SlimeBJumpFlag[5];


float Map1_EnemyCoreX[5] = { 870,150,990,570,720 };
float Map1_EnemyCoreY[5] = { 180,360,570,630,630 };
float Map2_EnemyCoreX[5] = { 360,840,1020,90,540 };
float Map2_EnemyCoreY[5] = { 120,120,420,450,540 };
float Map3_EnemyCoreX[5] = { 810,270,180,930,510 };
float Map3_EnemyCoreY[5] = { 120,180,480,540,750 };

float Respawn1_EnemyCoreX[5] = { 870,150,990,570,720 };
float Respawn1_EnemyCoreY[5] = { 180,360,570,630,630 };
float Respawn2_EnemyCoreX[5] = { 360,840,1020,90,540 };
float Respawn2_EnemyCoreY[5] = { 120,120,420,450,540 };
float Respawn3_EnemyCoreX[5] = { 810,270,180,930,510 };
float Respawn3_EnemyCoreY[5] = { 120,180,480,540,750 };


//�}�b�v��
#define ScreenSizeX    (1200)                       // ��ʂ̉���
#define ScreenSizeY    (900)                        // ��ʂ̏c��
#define BlockSize      (30)                         // ��̃`�b�v�̃T�C�Y
#define MapSizeX       (ScreenSizeX / BlockSize)    // �}�b�v�̉���
#define MapSizeY       (ScreenSizeY / BlockSize)    // �}�b�v�̏c��
int MapData[MapSizeY][MapSizeX] = {};



int FrameStartTime;        // �U�O�e�o�r�Œ�p�A���ԕۑ��p�ϐ�

void shuffle(int array[], int size) {
	for (int i = 0; i < size; i++) {
		int j = rand() % size;
		int t = array[i];
		array[i] = array[j];
		array[j] = t;
	}
}

// �}�b�v�`�b�v�̒l���擾����֐�
int GetChipParam(float X, float Y);

// �L�����N�^���}�b�v�Ƃ̓����蔻����l�����Ȃ���ړ�����֐�
int CharMove(float* X, float* Y, float* DownSP,
	float MoveX, float MoveY, float Size, char* JumpFlag);

// �A�N�V�����T���v���v���O�������C���֐�

// �}�b�v�Ƃ̓����蔻��( �߂�l 0:������Ȃ�����  1:���ӂɓ�������  2:�E�ӂɓ������� 3:��ӂɓ�������  4:���ӂɓ�������
int MapHitCheck(float X, float Y, float* MoveX, float* MoveY);
// �E�B���h�E�̃^�C�g���ɕ\�����镶����
const char TITLE[] = "LC1C_18_�^�J�n�V�R�E�^:�^�C�g��";

// �E�B���h�E����
const int WIN_WIDTH = 1200;

// �E�B���h�E�c��
const int WIN_HEIGHT = 900;
//----------���C���v���O����-------------------------------------------------------------------------------------------------------------------//
int WINAPI WinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ LPSTR lpCmdLine, _In_ int nCmdShow)
{
	// �E�B���h�E���[�h�ɐݒ�
	ChangeWindowMode(TRUE);

	// �E�B���h�E�T�C�Y���蓮�ł͕ύX�������A
	// ���E�B���h�E�T�C�Y�ɍ��킹�Ċg��ł��Ȃ��悤�ɂ���
	SetWindowSizeChangeEnableFlag(FALSE, FALSE);

	// �^�C�g����ύX
	SetMainWindowText(TITLE);

	// ��ʃT�C�Y�̍ő�T�C�Y�A�J���[�r�b�g����ݒ�(���j�^�[�̉𑜓x�ɍ��킹��)
	SetGraphMode(WIN_WIDTH, WIN_HEIGHT, 32);

	// ��ʃT�C�Y��ݒ�(�𑜓x�Ƃ̔䗦�Őݒ�)
	SetWindowSizeExtendRate(1.0);

	// ��ʂ̔w�i�F��ݒ肷��
	SetBackgroundColor(0, 0, 0);

	// DXlib�̏�����
	if (DxLib_Init() == -1) { return -1; }

	// (�_�u���o�b�t�@)�`���O���t�B�b�N�̈�͗��ʂ��w��
	SetDrawScreen(DX_SCREEN_BACK);

	// �摜�Ȃǂ̃��\�[�X�f�[�^�̕ϐ��錾�Ɠǂݍ���


	// �Q�[�����[�v�Ŏg���ϐ��̐錾
	//�V�[���؂�ւ�
	int Gamescene = 0;
	int StartImage;

	//�p�b�h��
	int Input = 0;
	int	EdgeInput;      // ���͏��

	int Pad;
	//�v���C���[��
	int PlayerFlag = 1;//0=����ł���,1=�����Ă��� 
	int PlayerLife = 6;
	int PlayerX1 = (PlayerCoreX - PLAYER_SIZE * 0.5F);
	int PlayerX2 = (PlayerCoreX + PLAYER_SIZE * 0.5F);
	int PlayerY1 = (PlayerCoreY - PLAYER_SIZE * 0.5F) - 20;
	int PlayerY2 = (PlayerCoreY + PLAYER_SIZE * 0.5F);
	float PlayerMoveX;
	float PlayerMoveY;
	int PlayerAttackFlag = 0;
	int PlayerAttackTimer = 10;
	int PlayerAttackRecharge = 36;
	int PlayerRechargeFlag = 0;
	int PlayerDirection = 0;//0=�E,1=��
	int PlayerSlashRIghtX = 0;
	int PlayerSlashRightY = 0;
	int PlayerSlashLeftX = 0;
	int PlayerSlashLeftY = 0;
	int PlayerRightWaitImage;
	int PlayerLeftWaitImage;
	int PlayerSlashRightImage;
	int PlayerSlashLeftImage;
	int PlayerHP2Image;
	int PlayerHP1Image;
	int PlayerHP0Image;
	int AttackTimer0Image;
	int AttackTimer3Image;
	int AttackTimer6Image;
	int AttackTimer9Image;
	int AttackTimer12Image;
	int AttackTimer15Image;


	int PlayerDamageFlag = 0;
	int EnemyTouchFlag = 0;
	int PlayerInvincibleFlag = 0;//���G���Ԃ̃t���O
	int PlayerInvincibleTimer = 60;//���G����
	//�G���u�i�X���C��A�j
	int SAC;//�o������X���C��A�̐�
	int SlimeAFlag[5] = {1,1,1,1,1};
	int SlimeALife[5] = {2,2,2,2,2};
	float SlimeAMoveX[5];
	float SlimeAMoveY[5];
	float SlimeAMoveTimer[5] = { 10,10,10,10,10 };
	int SlimeADirection[5] = {0,0,0,0,0};//0=�E,1=��,2=�~�܂�
	int SlimeARightWaitImage;
	int SlimeALeftWaitImage;
	int SlimeAX1[5] = {0,0,0,0,0};
	int SlimeAX2[5] = {0,0,0,0,0};
	int SlimeAY1[5] = {0,0,0,0,0};
	int SlimeAY2[5] = {0,0,0,0,0};

	int SlimeADamageFlag[5] = {0,0,0,0,0};
	int SlimeAInvincibleFlag[5] = {0,0,0,0,0};//���G���Ԃ̃t���O
	int SlimeAInvincibleTimer[5] = { 20,20,20,20,20 };

	int SlimeASearchFlag[5] = {0,0,0,0,0};
	int SlimeASearchRange = 100;


	//�G���u�i�X���C��B�j
	int SBC;//�o������X���C��A�̐�
	int SlimeBFlag[5] = { 1,1,1,1,1 };
	int SlimeBLife[5] = { 2,2,2,2,2 };
	float SlimeBMoveX[5];
	float SlimeBMoveY[5];
	float SlimeBMoveTimer[5] = { 10,10,10,10,10 };
	int SlimeBDirection[5] = { 0,0,0,0,0 };//0=�E,1=��,2=�~�܂�
	int SlimeBRightWaitImage;
	int SlimeBLeftWaitImage;
	int SlimeBX1[5];
	int SlimeBX2[5];
	int SlimeBY1[5];
	int SlimeBY2[5];

	int SlimeBDamageFlag[5] = { 0,0,0,0,0 };
	int SlimeBInvincibleFlag[5] = { 0,0,0,0,0 };//���G���Ԃ̃t���O
	int SlimeBInvincibleTimer[5] = { 20,20,20,20,20 };

	int SlimeBSearchFlag[5] = { 0,0,0,0,0 };
	int SlimeBSearchRange = 120;
	//�}�b�v��

	int DetectionX1;
	int DetectionX2;
	int DetectionY1;
	int DetectionY2;



	int LadderFlag = 0;
	int ClearDoorFlag = 0;
	int MapSelectFlag = 1;
	int MapCraftFlag = 1;
	int EnemryRespawnFlag = 1;

	int MapSelect;
	
	int StageMap[30][40] = {};
	


	int MAP_1[30][40] = {
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,

	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,

	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,

	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,

	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,

	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 5, 5, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 1,

	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 0, 0, 0, 0, 7, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1,

	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,

	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1

	};
	int MAP_2[30][40] = {
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,

	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,

	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 2, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 3, 1,
	1, 2, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 3, 1,

	1, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 1,
	1, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 1,
	1, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 1,
	1, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 1,

	1, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 1,
	1, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 2, 3, 1,
	1, 2, 3, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 1,
	1, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 1,

	1, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,

	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,

	1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1,
	1, 0, 4, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 5, 5, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 5, 5, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 5, 5, 0, 1,

	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1

	};
	int MAP_3[30][40] = {
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,

	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,

	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,

	1, 2, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 2, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,

	1, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
	1, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 1,
	1, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 1,
	1, 2, 3, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 1,

	1, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1,
	1, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1,

	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,

	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 0, 0, 7, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,

	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
	};

	int StageClearFlag = 0;
	int StageClearCount = 0;
	int YbuttonImage;
	int BlockImage;
	int Ladder1Image;
	int Ladder2Image;
	int DoorImage;
	int DoorRockImage;
	//�G���u�̃��X�|�[��
	  //�I�����ꂽ�}�b�v�̃��X�|�[���ʒu���L��
	
	int RespawnNumber[5] = {0,1,2,3,4};
	int StageRespawnCount = 0;
	int EnemySelectFlag = 1;
	int EnemyType[18] = {};
	int EnemyCount = 5;
	int ClearWave = 0;
	int RestartFlag = 0;
	int RestartTimer = 120;
	int RespawnMovie;
	int RespawnImage[11];
	int LoadFlag = 0;
	int LoadMovieTimer = 150;
	int LoadTimer = 10;
	int LoadMovie;
	int LoadMImage[20];
	int LoadImageCount = 0;
	int GameOverFlag = 0;
	int GameOverImage;
		
	int t = 0;
	int timer = 3;
	// �ŐV�̃L�[�{�[�h���p
	char keys[256] = { 0 };

	// 1���[�v(�t���[��)�O�̃L�[�{�[�h���
	char oldkeys[256] = { 0 };

	// �Q�[�����[�v
	StartImage = LoadGraph("StarrImage.PNG");
	GameOverImage = LoadGraph("GAME OVER.PNG");
	PlayerRightWaitImage = LoadGraph("My_Right_Wait.PNG");
	PlayerLeftWaitImage = LoadGraph("My_Left_Wait.PNG");
	PlayerSlashRightImage = LoadGraph("Attack_Slash_Right.PNG");
	PlayerSlashLeftImage = LoadGraph("Attack_Slash_Left.PNG");
	PlayerHP0Image = LoadGraph("PlayerHP0_Image.PNG");
	PlayerHP1Image = LoadGraph("PlayerHP1_Image.PNG");
	PlayerHP2Image = LoadGraph("PlayerHP2_Image.PNG");
	AttackTimer0Image = LoadGraph("AttackTimer0.PNG");
	AttackTimer3Image = LoadGraph("AttackTimer3.PNG");
	AttackTimer6Image = LoadGraph("AttackTimer6.PNG");
	AttackTimer9Image = LoadGraph("AttackTimer9.PNG");
	AttackTimer12Image = LoadGraph("AttackTimer12.PNG");
	AttackTimer15Image = LoadGraph("AttackTimer15.PNG");
	SlimeARightWaitImage = LoadGraph("SlimeA_Right_Wait.PNG");
	SlimeALeftWaitImage = LoadGraph("SlimeA_Left_Wait.PNG");
	SlimeBRightWaitImage = LoadGraph("SlimeB_Right_Wait.PNG");
	SlimeBLeftWaitImage = LoadGraph("SlimeB_Left_Wait.PNG");
	BlockImage = LoadGraph("Block.PNG");
	Ladder1Image = LoadGraph("LadderImage.PNG");
	Ladder2Image = LoadGraph("LadderImage2.PNG");
	DoorImage = LoadGraph("Door.PNG");
	DoorRockImage = LoadGraph("Door_Rock.PNG");
	YbuttonImage = LoadGraph("Y_button.PNG");
	RespawnMovie = LoadDivGraph("Respawn.PNG", 11, 11, 1, 60, 60, RespawnImage);
	LoadMovie = LoadDivGraph("Load.PNG", 20, 20, 1, 1200, 900, LoadMImage);
	while (1)
	{
		// �ŐV�̃L�[�{�[�h��񂾂������̂�1�t���[���O�̃L�[�{�[�h���Ƃ��ĕۑ�
		for (int i = 0; i < 256; ++i)
		{
			oldkeys[i] = keys[i];
		}
		// �ŐV�̃L�[�{�[�h�����擾
		GetHitKeyStateAll(keys);

		// ��ʃN���A
		ClearDrawScreen();
		//---------  ��������v���O�������L�q  ----------//
		//-------------------------------------------------�X�V����-----------------------------------------------------------------------//
		
		switch (Gamescene)
		{
			case 0://�X�^�[�g���
				if (keys[KEY_INPUT_SPACE] == 1 && oldkeys[KEY_INPUT_SPACE] == 0)
				{
					Gamescene = 2;

				}
				Map1_EnemyCoreX[0] = 870;
				Map1_EnemyCoreX[1] = 150;
				Map1_EnemyCoreX[2] = 990;
				Map1_EnemyCoreX[3] = 570;
				Map1_EnemyCoreX[4] = 720;

				Map1_EnemyCoreY[0] = 180;
				Map1_EnemyCoreY[1] = 360;
				Map1_EnemyCoreY[2] = 570;
				Map1_EnemyCoreY[3] = 630;
				Map1_EnemyCoreY[4] = 630;


				Map2_EnemyCoreX[0] = 360;
				Map2_EnemyCoreX[1] = 840;
				Map2_EnemyCoreX[2] = 1020;
				Map2_EnemyCoreX[3] = 90;
				Map2_EnemyCoreX[4] = 540;

				Map2_EnemyCoreY[0] = 120;
				Map2_EnemyCoreY[1] = 120;
				Map2_EnemyCoreY[2] = 420;
				Map2_EnemyCoreY[3] = 450;
				Map2_EnemyCoreY[4] = 540;


				Map3_EnemyCoreX[0] = 810;
				Map3_EnemyCoreX[1] = 270;
				Map3_EnemyCoreX[2] = 180;
				Map3_EnemyCoreX[3] = 930;
				Map3_EnemyCoreX[4] = 510;

				Map3_EnemyCoreY[0] = 120;
				Map3_EnemyCoreY[1] = 180;
				Map3_EnemyCoreY[2] = 480;
				Map3_EnemyCoreY[3] = 540;
				Map3_EnemyCoreY[4] = 750;
				GameOverFlag = 0;
				PlayerCoreX = 90;
			    PlayerCoreY = 860;
				PlayerFlag = 1;
				PlayerLife = 6;
				DrawGraph(0, 0, StartImage, true);
				break;
			case 1://���j���[���
				break;
			case 2://�v���C���
				//�}�b�v�I��
				if (MapSelectFlag == 1)
				{
					srand(time(nullptr));
					MapSelect = (rand() % 3) + 1;
					if (MapSelectFlag == 1)
					{
						MapSelectFlag = 0;
					}
				}
				//�}�b�v����
				if (MapCraftFlag == 1)
				{
					switch (MapSelect)
					{
						case 1:
							for (int i = 0; i < 30; i++)
							{
								for (int j = 0; j < 40; j++)
								{
									StageMap[i][j] = MAP_1[i][j];
								}
							}
							break;
						case 2:
							for (int i = 0; i < 30; i++)
							{
								for (int j = 0; j < 40; j++)
								{
									StageMap[i][j] = MAP_2[i][j];
								}
							}
							break;
						case 3:
							for (int i = 0; i < 30; i++)
							{
								for (int j = 0; j < 40; j++)
								{
									StageMap[i][j] = MAP_3[i][j];
								}
							}
							break;
					}





					for (int i = 0; i < 30; i++)
					{
						for (int j = 0; j < 40; j++)
						{
							MapData[i][j] = StageMap[i][j];
						}
					}
					if (MapCraftFlag == 1)
					{
						MapCraftFlag = 0;
					}
				}
				//�o������G���u�̊��������߂�
				if (EnemySelectFlag == 1)
				{

					while (1)
					{
						srand(time(nullptr));
						SAC = (rand() % 5) + 1;
						SBC = 5 - SAC;
						if (SAC + SBC == 5)
						{
							EnemySelectFlag = 0;
						}
						break;
					}





					shuffle(RespawnNumber, 5);//�V���b�t��

				}

				for (int i = 0; i < 18; i++)
				{
					if (EnemyType[i] == 1)
					{

					}
				}

				// �R���g���[���[�̓��͂𓾂�
				Pad = GetJoypadInputState(DX_INPUT_KEY_PAD1);						// �p�b�h�P�ƃL�[�{�[�h������͂𓾂�
				EdgeInput = Pad & ~Input;												// �G�b�W����������͂��Z�b�g	  
				Input = Pad;															// ���͏�Ԃ̕ۑ�




				//----------�v���C���[�i���@�j-----------------------------//
				{
					if (PlayerLife <= 0)//�v���C���[���S
					{
						GameOverFlag = 1;
						PlayerFlag = 0;
					}
					// �ړ��ʂ̏�����
					PlayerMoveX = 0.0F;
					PlayerMoveY = 0.0F;
					// ���E�̈ړ�����
					if ((Input & PAD_INPUT_LEFT) != 0)
					{
						PlayerMoveX -= PLAYER_SPEED;
						PlayerDirection = 1;
					}

					if ((Input & PAD_INPUT_RIGHT) != 0)
					{
						PlayerMoveX += PLAYER_SPEED;
						PlayerDirection = 0;
					}

					// �n�ɑ��������Ă���ꍇ�̂݃W�����v�{�^��(�{�^���P or �y�L�[)������
					if (PlayerJumpFlag == 0 && (EdgeInput & PAD_INPUT_1) != 0)
					{
						PlayerDownSpeed = -PLAYER_JUMP_POWER;
						PlayerJumpFlag = 1;
					}
					// ��������
					PlayerDownSpeed += PLAYER_G;
					PlayerMoveY = PlayerDownSpeed;														// �������x���ړ��ʂɉ�����
					CharMove(&PlayerCoreX, &PlayerCoreY, &PlayerDownSpeed, PlayerMoveX, PlayerMoveY, PLAYER_SIZE, &PlayerJumpFlag);	// �ړ��ʂɊ�Â��ăL�����N�^�̍��W���ړ�

					DetectionX1 = ((PlayerX1 / 30) + 1);
					DetectionX2 = ((PlayerX2 / 30) + 1);
					DetectionY1 = ((PlayerY1 / 30) + 1);
					DetectionY2 = ((PlayerY2 / 30) + 1);
					//��q
					if (MapData[DetectionY1][DetectionX1] == 2 || MapData[DetectionY1][DetectionX2] == 2 || MapData[DetectionY2][DetectionX1] == 2 || MapData[DetectionY2][DetectionX2] == 2 || MapData[DetectionY1][DetectionX1] == 3 || MapData[DetectionY1][DetectionX2] == 3 || MapData[DetectionY2][DetectionX1] == 3 || MapData[DetectionY2][DetectionX2] == 3)
					{
						LadderFlag = 1;
					}
					else if (MapData[DetectionY1 - 1][DetectionX1 - 1] == 2 || MapData[DetectionY1 - 1][DetectionX2 - 1] == 2 || MapData[DetectionY2 - 1][DetectionX1 - 1] == 2 || MapData[DetectionY2 - 1][DetectionX2 - 1] == 2 || MapData[DetectionY1 - 1][DetectionX1 - 1] == 3 || MapData[DetectionY1 - 1][DetectionX2 - 1] == 3 || MapData[DetectionY2 - 1][DetectionX1 - 1] == 3 || MapData[DetectionY2 - 1][DetectionX2 - 1] == 3)
					{
						LadderFlag = 1;
					}
					else
					{
						LadderFlag = 0;
					}

					if (LadderFlag == 1 && (Input & PAD_INPUT_UP) != 0)
					{
						PlayerCoreY -= PLAYER_SPEED;
						PLAYER_G = 0;
						PlayerDownSpeed = 0;
					}
					else
					{
						PLAYER_G = 0.3F;
					}

					//�h�A�ɓ���
					if ((MapData[DetectionY1][DetectionX1] == 5 || MapData[DetectionY1][DetectionX2] == 5 || MapData[DetectionY2][DetectionX1] == 5 || MapData[DetectionY2][DetectionX2] == 5) && StageClearFlag == 1)
					{
						ClearDoorFlag = 1;
					}
					else if ((MapData[DetectionY1 - 1][DetectionX1 - 1] == 5 || MapData[DetectionY1 - 1][DetectionX2 - 1] == 5 || MapData[DetectionY2 - 1][DetectionX1 - 1] == 5 || MapData[DetectionY2 - 1][DetectionX2 - 1] == 5) && StageClearFlag == 1)
					{
						ClearDoorFlag = 1;
					}
					else
					{
						ClearDoorFlag = 0;
					}

					// �v���C���[�̈ړ�����
					PlayerX1 = (PlayerCoreX - PLAYER_SIZE * 0.5F);
					PlayerX2 = (PlayerCoreX + PLAYER_SIZE * 0.5F);
					PlayerY1 = (PlayerCoreY - PLAYER_SIZE * 0.5F) - 20;
					PlayerY2 = (PlayerCoreY + PLAYER_SIZE * 0.5F);


					//�v���C���[�̍U��
					PlayerSlashRIghtX = PlayerX1 + 57;
					PlayerSlashRightY = PlayerY1 + 39;
					PlayerSlashLeftX = PlayerX1 - 51;
					PlayerSlashLeftY = PlayerY1 + 39;


					if ((Input & PAD_INPUT_2) != 0 && PlayerAttackFlag == 0 && PlayerRechargeFlag == 0)//�{�^���������ƍU������
					{
						PlayerAttackFlag = 1;
						PlayerAttackRecharge = 36;
						PlayerRechargeFlag = 1;
					}


					if (PlayerRechargeFlag == 1)//�U���̊Ԋu
					{
						while (1)
						{
							PlayerAttackRecharge -= 1;
							if (PlayerAttackRecharge <= 0)
							{
								PlayerAttackRecharge = 36;
								PlayerRechargeFlag = 0;
							}
							break;
						}
					}



					if (PlayerAttackFlag == 1)//�U���̔���
					{
						while (1)
						{
							PlayerAttackTimer -= 1;
							if (PlayerAttackTimer <= 0)
							{
								PlayerAttackTimer = 10;
								PlayerAttackFlag = 0;
							}
							break;
						}
					}




				}

				//-----------------------------------�G���u�i�X���C���j-----------------------------------------//
				// �X���C��A

				for (int i = 0; i < SAC; i++)
				{
					SlimeAMoveX[RespawnNumber[i]] = 0.0F;
					SlimeAMoveY[RespawnNumber[i]] = 0.0F;
					if (SlimeALife[RespawnNumber[i]] <= 0)
					{
						SlimeAFlag[RespawnNumber[i]] = 0;
					}

					if (SlimeAFlag[RespawnNumber[i]] == 1)//�X���C���̈ړ����������߂�
					{
						while (1)
						{
							SlimeAMoveTimer[RespawnNumber[i]] -= 1;
							if (SlimeAMoveTimer[RespawnNumber[i]] <= 0)
							{

								SlimeAMoveTimer[RespawnNumber[i]] = 10;
								SlimeADirection[RespawnNumber[i]] = rand() % 3;//0=�E,1=��,2=�~�܂�

							}
							break;
						}
					}


					//�X���C���̈ړ�
					if (SlimeADirection[RespawnNumber[i]] == 0)
					{
						while (1)
						{
							SlimeAMoveX[RespawnNumber[i]] += SLIME_SPEED;
							if (SlimeADirection[RespawnNumber[i]] != 0)
							{

							}
							break;
						}
					}
					else if (SlimeADirection[RespawnNumber[i]] == 1)
					{
						while (1)
						{
							SlimeAMoveX[RespawnNumber[i]] -= SLIME_SPEED;
							if (SlimeADirection[RespawnNumber[i]] != 1)
							{

							}
							break;
						}
					}
					else if (SlimeADirection[RespawnNumber[i]] == 2)
					{
						SlimeAMoveX[RespawnNumber[i]] = SlimeAMoveX[RespawnNumber[i]];
					}

					//-------------------------�}�b�v�ɂ���ĕύX------------------------------//
					if (MapSelect == 1)
					{
						SlimeAX1[RespawnNumber[i]] = (Map1_EnemyCoreX[RespawnNumber[i]] - SLIME_SIZE * 0.5F);
						SlimeAX2[RespawnNumber[i]] = (Map1_EnemyCoreX[RespawnNumber[i]] + SLIME_SIZE * 0.5F);
						SlimeAY1[RespawnNumber[i]] = (Map1_EnemyCoreY[RespawnNumber[i]] - SLIME_SIZE * 0.5F) + 9;
						SlimeAY2[RespawnNumber[i]] = (Map1_EnemyCoreY[RespawnNumber[i]] + SLIME_SIZE * 0.5F);

						// ��������
						SlimeADownSpeed[RespawnNumber[i]] += SLIME_G;
						SlimeAMoveY[RespawnNumber[i]] = SlimeADownSpeed[RespawnNumber[i]];														// �������x���ړ��ʂɉ�����
						CharMove(&Map1_EnemyCoreX[RespawnNumber[i]], &Map1_EnemyCoreY[RespawnNumber[i]], &SlimeADownSpeed[RespawnNumber[i]], SlimeAMoveX[RespawnNumber[i]], SlimeAMoveY[RespawnNumber[i]], SLIME_SIZE, &SlimeAJumpFlag[RespawnNumber[i]]);	// �ړ��ʂɊ�Â��ăL�����N�^�̍��W���ړ�

						//�X���C���̈ړ�����
						if (SlimeAX1[RespawnNumber[i]] <= 0)
						{
							SlimeADirection[RespawnNumber[i]] = 0;
						}
						if (SlimeAX2[RespawnNumber[i]] >= 1200)
						{
							SlimeADirection[RespawnNumber[i]] = 1;
						}

						//�X���C���̍��G
						if (SlimeAFlag[RespawnNumber[i]] == 1)
						{
							if ((Map1_EnemyCoreX[RespawnNumber[i]] - SlimeASearchRange) < PlayerX2 && PlayerX1 < (Map1_EnemyCoreX[RespawnNumber[i]] + SlimeASearchRange) && (Map1_EnemyCoreY[i] - SlimeASearchRange) < PlayerY2 && PlayerY1 < (Map1_EnemyCoreY[i] + SlimeASearchRange))
							{
								SlimeASearchFlag[RespawnNumber[i]] = 1;
							}
							else
							{
								SlimeASearchFlag[RespawnNumber[i]] = 0;
							}
						}
						if (SlimeASearchFlag[RespawnNumber[i]] == 1)
						{
							if (Map1_EnemyCoreX[RespawnNumber[i]] < PlayerCoreX)
							{
								SlimeADirection[RespawnNumber[i]] = 0;
							}
							if (Map1_EnemyCoreX[RespawnNumber[i]] > PlayerCoreX)
							{
								SlimeADirection[RespawnNumber[i]] = 1;
							}
						}
					}

					if (MapSelect == 2)
					{
						SlimeAX1[RespawnNumber[i]] = (Map2_EnemyCoreX[RespawnNumber[i]] - SLIME_SIZE * 0.5F);
						SlimeAX2[RespawnNumber[i]] = (Map2_EnemyCoreX[RespawnNumber[i]] + SLIME_SIZE * 0.5F);
						SlimeAY1[RespawnNumber[i]] = (Map2_EnemyCoreY[RespawnNumber[i]] - SLIME_SIZE * 0.5F) + 9;
						SlimeAY2[RespawnNumber[i]] = (Map2_EnemyCoreY[RespawnNumber[i]] + SLIME_SIZE * 0.5F);

						// ��������
						SlimeADownSpeed[RespawnNumber[i]] += SLIME_G;
						SlimeAMoveY[RespawnNumber[i]] = SlimeADownSpeed[RespawnNumber[i]];														// �������x���ړ��ʂɉ�����
						CharMove(&Map2_EnemyCoreX[RespawnNumber[i]], &Map2_EnemyCoreY[RespawnNumber[i]], &SlimeADownSpeed[RespawnNumber[i]], SlimeAMoveX[RespawnNumber[i]], SlimeAMoveY[RespawnNumber[i]], SLIME_SIZE, &SlimeAJumpFlag[RespawnNumber[i]]);	// �ړ��ʂɊ�Â��ăL�����N�^�̍��W���ړ�

						//�X���C���̈ړ�����
						if (SlimeAX1[RespawnNumber[i]] <= 0)
						{
							SlimeADirection[RespawnNumber[i]] = 0;
						}
						if (SlimeAX2[RespawnNumber[i]] >= 1200)
						{
							SlimeADirection[RespawnNumber[i]] = 1;
						}

						//�X���C���̍��G
						if (SlimeAFlag[RespawnNumber[i]] == 1)
						{
							if ((Map2_EnemyCoreX[RespawnNumber[i]] - SlimeASearchRange) < PlayerX2 && PlayerX1 < (Map2_EnemyCoreX[RespawnNumber[i]] + SlimeASearchRange) && (Map2_EnemyCoreY[RespawnNumber[i]] - SlimeASearchRange) < PlayerY2 && PlayerY1 < (Map2_EnemyCoreY[RespawnNumber[i]] + SlimeASearchRange))
							{
								SlimeASearchFlag[RespawnNumber[i]] = 1;
							}
							else
							{
								SlimeASearchFlag[RespawnNumber[i]] = 0;
							}
						}
						if (SlimeASearchFlag[RespawnNumber[i]] == 1)
						{
							if (Map2_EnemyCoreX[RespawnNumber[i]] < PlayerCoreX)
							{
								SlimeADirection[RespawnNumber[i]] = 0;
							}
							if (Map2_EnemyCoreX[RespawnNumber[i]] > PlayerCoreX)
							{
								SlimeADirection[RespawnNumber[i]] = 1;
							}
						}
					}

					if (MapSelect == 3)
					{
						SlimeAX1[RespawnNumber[i]] = (Map3_EnemyCoreX[RespawnNumber[i]] - SLIME_SIZE * 0.5F);
						SlimeAX2[RespawnNumber[i]] = (Map3_EnemyCoreX[RespawnNumber[i]] + SLIME_SIZE * 0.5F);
						SlimeAY1[RespawnNumber[i]] = (Map3_EnemyCoreY[RespawnNumber[i]] - SLIME_SIZE * 0.5F) + 9;
						SlimeAY2[RespawnNumber[i]] = (Map3_EnemyCoreY[RespawnNumber[i]] + SLIME_SIZE * 0.5F);

						// ��������
						SlimeADownSpeed[RespawnNumber[i]] += SLIME_G;
						SlimeAMoveY[RespawnNumber[i]] = SlimeADownSpeed[RespawnNumber[i]];														// �������x���ړ��ʂɉ�����
						CharMove(&Map3_EnemyCoreX[RespawnNumber[i]], &Map3_EnemyCoreY[RespawnNumber[i]], &SlimeADownSpeed[RespawnNumber[i]], SlimeAMoveX[RespawnNumber[i]], SlimeAMoveY[RespawnNumber[i]], SLIME_SIZE, &SlimeAJumpFlag[RespawnNumber[i]]);	// �ړ��ʂɊ�Â��ăL�����N�^�̍��W���ړ�

						//�X���C���̈ړ�����
						if (SlimeAX1[RespawnNumber[i]] <= 0)
						{
							SlimeADirection[RespawnNumber[i]] = 0;
						}
						if (SlimeAX2[RespawnNumber[i]] >= 1200)
						{
							SlimeADirection[RespawnNumber[i]] = 1;
						}

						//�X���C���̍��G
						if (SlimeAFlag[RespawnNumber[i]] == 1)
						{
							if ((Map3_EnemyCoreX[RespawnNumber[i]] - SlimeASearchRange) < PlayerX2 && PlayerX1 < (Map3_EnemyCoreX[RespawnNumber[i]] + SlimeASearchRange) && (Map3_EnemyCoreY[RespawnNumber[i]] - SlimeASearchRange) < PlayerY2 && PlayerY1 < (Map3_EnemyCoreY[RespawnNumber[i]] + SlimeASearchRange))
							{
								SlimeASearchFlag[RespawnNumber[i]] = 1;
							}
							else
							{
								SlimeASearchFlag[RespawnNumber[i]] = 0;
							}
						}
						if (SlimeASearchFlag[RespawnNumber[i]] == 1)
						{
							if (Map3_EnemyCoreX[RespawnNumber[i]] < PlayerCoreX)
							{
								SlimeADirection[RespawnNumber[i]] = 0;
							}
							if (Map3_EnemyCoreX[RespawnNumber[i]] > PlayerCoreX)
							{
								SlimeADirection[RespawnNumber[i]] = 1;
							}
						}
					}












					if (PlayerDirection == 0 && PlayerAttackFlag == 1)
					{
						if (SlimeAX1[RespawnNumber[i]] < PlayerSlashRIghtX + 51 && PlayerSlashRIghtX < SlimeAX2[RespawnNumber[i]] && SlimeAY1[RespawnNumber[i]] < PlayerSlashRightY + 39 && PlayerSlashRightY < SlimeAY2[RespawnNumber[i]] && SlimeAInvincibleFlag[RespawnNumber[i]] == 0)
						{
							SlimeADamageFlag[RespawnNumber[i]] = 1;
						}
					}
					if (PlayerDirection == 1 && PlayerAttackFlag == 1)
					{
						if (SlimeAX1[RespawnNumber[i]] < PlayerSlashLeftX + 51 && PlayerSlashLeftX < SlimeAX2[RespawnNumber[i]] && SlimeAY1[RespawnNumber[i]] < PlayerSlashLeftY + 39 && PlayerSlashLeftY < SlimeAY2[RespawnNumber[i]] && SlimeAInvincibleFlag[RespawnNumber[i]] == 0)
						{
							SlimeADamageFlag[RespawnNumber[i]] = 1;
						}
					}



					if (SlimeADamageFlag[RespawnNumber[i]] == 1)
					{
						SlimeAInvincibleFlag[RespawnNumber[i]] = 1;
						SlimeALife[RespawnNumber[i]] = SlimeALife[RespawnNumber[i]] - 1;
						SlimeADamageFlag[RespawnNumber[i]] = 0;
						if (SlimeALife[RespawnNumber[i]] == 0)
						{
							EnemyCount = EnemyCount - 1;
						}
					}
					if (SlimeAInvincibleFlag[RespawnNumber[i]] == 1)//���G���Ԃ̃^�C�}�[
					{
						while (1)
						{
							SlimeAInvincibleTimer[RespawnNumber[i]] -= 1;
							if (SlimeAInvincibleTimer[RespawnNumber[i]] <= 0)
							{
								SlimeAInvincibleTimer[RespawnNumber[i]] = 20;
								SlimeAInvincibleFlag[RespawnNumber[i]] = 0;
							}
							break;
						}
					}
					//�v���C���[�ƓG���u�̓����蔻��  �Ԃ������Ƃ�
					  //�X���C���p
					if (SlimeAFlag[RespawnNumber[i]] == 1)//�G�ꂽ�Ƃ�
					{
						if (SlimeAX1[RespawnNumber[i]] < PlayerX2 && PlayerX1 < SlimeAX2[RespawnNumber[i]] && SlimeAY1[RespawnNumber[i]] < PlayerY2 && PlayerY1 < SlimeAY2[RespawnNumber[i]])
						{
							EnemyTouchFlag = 1;
						}
						else
						{
							EnemyTouchFlag = 0;
						}


					}
					if (EnemyTouchFlag == 1 && PlayerInvincibleFlag == 0)//�_���[�W���󂯂���� &�@���G�ł͂Ȃ�����
					{
						PlayerDamageFlag = 1;
					}
					else
					{
						PlayerDamageFlag = 0;
					}
					if (PlayerDamageFlag == 1)
					{
						PlayerInvincibleFlag = 1;
						PlayerLife = PlayerLife - 1;
					}
					if (PlayerInvincibleFlag == 1)//���G���Ԃ̃^�C�}�[
					{
						while (1)
						{
							PlayerInvincibleTimer -= 1;
							if (PlayerInvincibleTimer <= 0)
							{
								PlayerInvincibleTimer = 60;
								PlayerInvincibleFlag = 0;
							}
							break;
						}
					}
				}
				//------�X���C��B-----------------------------------//
				for (int i = 0; i < SBC; i++)
				{
					SlimeBMoveX[RespawnNumber[i + SAC]] = 0.0F;
					SlimeBMoveY[RespawnNumber[i + SAC]] = 0.0F;
					if (SlimeBLife[RespawnNumber[i + SAC]] <= 0)
					{
						SlimeBFlag[RespawnNumber[i + SAC]] = 0;
					}

					if (SlimeBFlag[RespawnNumber[i + SAC]] == 1)//�X���C���̈ړ����������߂�
					{
						while (1)
						{
							SlimeBMoveTimer[RespawnNumber[i + SAC]] -= 1;
							if (SlimeBMoveTimer[RespawnNumber[i + SAC]] <= 0)
							{

								SlimeBMoveTimer[RespawnNumber[i + SAC]] = 10;
								SlimeBDirection[RespawnNumber[i + SAC]] = rand() % 3;//0=�E,1=��,2=�~�܂�

							}
							break;
						}
					}


					//�X���C���̈ړ�
					if (SlimeBDirection[RespawnNumber[i + SAC]] == 0)
					{
						while (1)
						{
							SlimeBMoveX[RespawnNumber[i + SAC]] += SLIME_SPEED;
							if (SlimeBDirection[RespawnNumber[i + SAC]] != 0)
							{

							}
							break;
						}
					}
					else if (SlimeBDirection[RespawnNumber[i + SAC]] == 1)
					{
						while (1)
						{
							SlimeBMoveX[RespawnNumber[i + SAC]] -= SLIME_SPEED;
							if (SlimeBDirection[RespawnNumber[i + SAC]] != 1)
							{

							}
							break;
						}
					}
					else if (SlimeBDirection[RespawnNumber[i + SAC]] == 2)
					{
						SlimeBMoveX[RespawnNumber[i + SAC]] = SlimeBMoveX[RespawnNumber[i + SAC]];
					}

					//-------------------------�}�b�v�ɂ���ĕύX------------------------------//
					if (MapSelect == 1)
					{
						SlimeBX1[RespawnNumber[i + SAC]] = (Map1_EnemyCoreX[RespawnNumber[i + SAC]] - SLIME_SIZE * 0.5F);
						SlimeBX2[RespawnNumber[i + SAC]] = (Map1_EnemyCoreX[RespawnNumber[i + SAC]] + SLIME_SIZE * 0.5F);
						SlimeBY1[RespawnNumber[i + SAC]] = (Map1_EnemyCoreY[RespawnNumber[i + SAC]] - SLIME_SIZE * 0.5F) + 9;
						SlimeBY2[RespawnNumber[i + SAC]] = (Map1_EnemyCoreY[RespawnNumber[i + SAC]] + SLIME_SIZE * 0.5F);

						// ��������
						SlimeBDownSpeed[RespawnNumber[i + SAC]] += SLIME_G;
						SlimeBMoveY[RespawnNumber[i + SAC]] = SlimeBDownSpeed[RespawnNumber[i + SAC]];														// �������x���ړ��ʂɉ�����
						CharMove(&Map1_EnemyCoreX[RespawnNumber[i + SAC]], &Map1_EnemyCoreY[RespawnNumber[i + SAC]], &SlimeBDownSpeed[RespawnNumber[i + SAC]], SlimeBMoveX[RespawnNumber[i + SAC]], SlimeBMoveY[RespawnNumber[i + SAC]], SLIME_SIZE, &SlimeBJumpFlag[RespawnNumber[i + SAC]]);	// �ړ��ʂɊ�Â��ăL�����N�^�̍��W���ړ�

						//�X���C���̈ړ�����
						if (SlimeBX1[RespawnNumber[i + SAC]] <= 0)
						{
							SlimeBDirection[RespawnNumber[i + SAC]] = 0;
						}
						if (SlimeBX2[RespawnNumber[i + SAC]] >= 1200)
						{
							SlimeBDirection[RespawnNumber[i + SAC]] = 1;
						}

						//�X���C���̍��G
						if (SlimeBFlag[RespawnNumber[i + SAC]] == 1)
						{
							if ((Map1_EnemyCoreX[RespawnNumber[i + SAC]] - SlimeBSearchRange) < PlayerX2 && PlayerX1 < (Map1_EnemyCoreX[RespawnNumber[i + SAC]] + SlimeBSearchRange) && (Map1_EnemyCoreY[i + SAC] - SlimeBSearchRange) < PlayerY2 && PlayerY1 < (Map1_EnemyCoreY[i + SAC] + SlimeBSearchRange))
							{
								SlimeBSearchFlag[RespawnNumber[i + SAC]] = 1;
							}
							else
							{
								SlimeBSearchFlag[RespawnNumber[i + SAC]] = 0;
							}
						}
						if (SlimeBSearchFlag[RespawnNumber[i + SAC]] == 1)
						{
							if (Map1_EnemyCoreX[RespawnNumber[i + SAC]] < PlayerCoreX)
							{
								SlimeBDirection[RespawnNumber[i + SAC]] = 0;
							}
							if (Map1_EnemyCoreX[RespawnNumber[i + SAC]] > PlayerCoreX)
							{
								SlimeBDirection[RespawnNumber[i + SAC]] = 1;
							}
						}
					}

					if (MapSelect == 2)
					{
						SlimeBX1[RespawnNumber[i + SAC]] = (Map2_EnemyCoreX[RespawnNumber[i + SAC]] - SLIME_SIZE * 0.5F);
						SlimeBX2[RespawnNumber[i + SAC]] = (Map2_EnemyCoreX[RespawnNumber[i + SAC]] + SLIME_SIZE * 0.5F);
						SlimeBY1[RespawnNumber[i + SAC]] = (Map2_EnemyCoreY[RespawnNumber[i + SAC]] - SLIME_SIZE * 0.5F) + 9;
						SlimeBY2[RespawnNumber[i + SAC]] = (Map2_EnemyCoreY[RespawnNumber[i + SAC]] + SLIME_SIZE * 0.5F);

						// ��������
						SlimeBDownSpeed[RespawnNumber[i + SAC]] += SLIME_G;
						SlimeBMoveY[RespawnNumber[i + SAC]] = SlimeBDownSpeed[RespawnNumber[i + SAC]];														// �������x���ړ��ʂɉ�����
						CharMove(&Map2_EnemyCoreX[RespawnNumber[i + SAC]], &Map2_EnemyCoreY[RespawnNumber[i + SAC]], &SlimeBDownSpeed[RespawnNumber[i + SAC]], SlimeBMoveX[RespawnNumber[i + SAC]], SlimeBMoveY[RespawnNumber[i + SAC]], SLIME_SIZE, &SlimeBJumpFlag[RespawnNumber[i + SAC]]);	// �ړ��ʂɊ�Â��ăL�����N�^�̍��W���ړ�

						//�X���C���̈ړ�����
						if (SlimeBX1[RespawnNumber[i + SAC]] <= 0)
						{
							SlimeBDirection[RespawnNumber[i + SAC]] = 0;
						}
						if (SlimeBX2[RespawnNumber[i + SAC]] >= 1200)
						{
							SlimeBDirection[RespawnNumber[i + SAC]] = 1;
						}

						//�X���C���̍��G
						if (SlimeBFlag[RespawnNumber[i + SAC]] == 1)
						{
							if ((Map2_EnemyCoreX[RespawnNumber[i + SAC]] - SlimeBSearchRange) < PlayerX2 && PlayerX1 < (Map2_EnemyCoreX[RespawnNumber[i + SAC]] + SlimeBSearchRange) && (Map2_EnemyCoreY[RespawnNumber[i + SAC]] - SlimeBSearchRange) < PlayerY2 && PlayerY1 < (Map2_EnemyCoreY[RespawnNumber[i + SAC]] + SlimeBSearchRange))
							{
								SlimeBSearchFlag[RespawnNumber[i + SAC]] = 1;
							}
							else
							{
								SlimeBSearchFlag[RespawnNumber[i + SAC]] = 0;
							}
						}
						if (SlimeBSearchFlag[RespawnNumber[i + SAC]] == 1)
						{
							if (Map2_EnemyCoreX[RespawnNumber[i + SAC]] < PlayerCoreX)
							{
								SlimeBDirection[RespawnNumber[i + SAC]] = 0;
							}
							if (Map2_EnemyCoreX[RespawnNumber[i + SAC]] > PlayerCoreX)
							{
								SlimeBDirection[RespawnNumber[i + SAC]] = 1;
							}
						}
					}

					if (MapSelect == 3)
					{
						SlimeBX1[RespawnNumber[i + SAC]] = (Map3_EnemyCoreX[RespawnNumber[i + SAC]] - SLIME_SIZE * 0.5F);
						SlimeBX2[RespawnNumber[i + SAC]] = (Map3_EnemyCoreX[RespawnNumber[i + SAC]] + SLIME_SIZE * 0.5F);
						SlimeBY1[RespawnNumber[i + SAC]] = (Map3_EnemyCoreY[RespawnNumber[i + SAC]] - SLIME_SIZE * 0.5F) + 9;
						SlimeBY2[RespawnNumber[i + SAC]] = (Map3_EnemyCoreY[RespawnNumber[i + SAC]] + SLIME_SIZE * 0.5F);

						// ��������
						SlimeBDownSpeed[RespawnNumber[i + SAC]] += SLIME_G;
						SlimeBMoveY[RespawnNumber[i + SAC]] = SlimeBDownSpeed[RespawnNumber[i + SAC]];														// �������x���ړ��ʂɉ�����
						CharMove(&Map3_EnemyCoreX[RespawnNumber[i + SAC]], &Map3_EnemyCoreY[RespawnNumber[i + SAC]], &SlimeBDownSpeed[RespawnNumber[i + SAC]], SlimeBMoveX[RespawnNumber[i + SAC]], SlimeBMoveY[RespawnNumber[i + SAC]], SLIME_SIZE, &SlimeBJumpFlag[RespawnNumber[i + SAC]]);	// �ړ��ʂɊ�Â��ăL�����N�^�̍��W���ړ�

						//�X���C���̈ړ�����
						if (SlimeBX1[RespawnNumber[i + SAC]] <= 0)
						{
							SlimeBDirection[RespawnNumber[i + SAC]] = 0;
						}
						if (SlimeBX2[RespawnNumber[i + SAC]] >= 1200)
						{
							SlimeBDirection[RespawnNumber[i + SAC]] = 1;
						}

						//�X���C���̍��G
						if (SlimeBFlag[RespawnNumber[i + SAC]] == 1)
						{
							if ((Map3_EnemyCoreX[RespawnNumber[i + SAC]] - SlimeBSearchRange) < PlayerX2 && PlayerX1 < (Map3_EnemyCoreX[RespawnNumber[i + SAC]] + SlimeBSearchRange) && (Map3_EnemyCoreY[RespawnNumber[i + SAC]] - SlimeBSearchRange) < PlayerY2 && PlayerY1 < (Map3_EnemyCoreY[RespawnNumber[i + SAC]] + SlimeBSearchRange))
							{
								SlimeBSearchFlag[RespawnNumber[i + SAC]] = 1;
							}
							else
							{
								SlimeBSearchFlag[RespawnNumber[i + SAC]] = 0;
							}
						}
						if (SlimeBSearchFlag[RespawnNumber[i + SAC]] == 1)
						{
							if (Map3_EnemyCoreX[RespawnNumber[i + SAC]] < PlayerCoreX)
							{
								SlimeBDirection[RespawnNumber[i + SAC]] = 0;
							}
							if (Map3_EnemyCoreX[RespawnNumber[i + SAC]] > PlayerCoreX)
							{
								SlimeBDirection[RespawnNumber[i]] = 1;
							}
						}
					}












					if (PlayerDirection == 0 && PlayerAttackFlag == 1)
					{
						if (SlimeBX1[RespawnNumber[i + SAC]] < PlayerSlashRIghtX + 51 && PlayerSlashRIghtX < SlimeBX2[RespawnNumber[i + SAC]] && SlimeBY1[RespawnNumber[i + SAC]] < PlayerSlashRightY + 39 && PlayerSlashRightY < SlimeBY2[RespawnNumber[i + SAC]] && SlimeBInvincibleFlag[RespawnNumber[i + SAC]] == 0)
						{
							SlimeBDamageFlag[RespawnNumber[i + SAC]] = 1;
						}
					}
					if (PlayerDirection == 1 && PlayerAttackFlag == 1)
					{
						if (SlimeBX1[RespawnNumber[i + SAC]] < PlayerSlashLeftX + 51 && PlayerSlashLeftX < SlimeBX2[RespawnNumber[i + SAC]] && SlimeBY1[RespawnNumber[i + SAC]] < PlayerSlashLeftY + 39 && PlayerSlashLeftY < SlimeBY2[RespawnNumber[i + SAC]] && SlimeBInvincibleFlag[RespawnNumber[i + SAC]] == 0)
						{
							SlimeBDamageFlag[RespawnNumber[i + SAC]] = 1;
						}
					}



					if (SlimeBDamageFlag[RespawnNumber[i + SAC]] == 1)
					{
						SlimeBInvincibleFlag[RespawnNumber[i + SAC]] = 1;
						SlimeBLife[RespawnNumber[i + SAC]] = SlimeBLife[RespawnNumber[i + SAC]] - 1;
						SlimeBDamageFlag[RespawnNumber[i + SAC]] = 0;
						if (SlimeBLife[RespawnNumber[i + SAC]] == 0)
						{
							EnemyCount = EnemyCount - 1;
						}
					}
					if (SlimeBInvincibleFlag[RespawnNumber[i + SAC]] == 1)//���G���Ԃ̃^�C�}�[
					{
						while (1)
						{
							SlimeBInvincibleTimer[RespawnNumber[i + SAC]] -= 1;
							if (SlimeBInvincibleTimer[RespawnNumber[i + SAC]] <= 0)
							{
								SlimeBInvincibleTimer[RespawnNumber[i + SAC]] = 20;
								SlimeBInvincibleFlag[RespawnNumber[i + SAC]] = 0;
							}
							break;
						}
					}
					//�v���C���[�ƓG���u�̓����蔻��  �Ԃ������Ƃ�
					  //�X���C���p
					if (SlimeBFlag[RespawnNumber[i + SAC]] == 1)//�G�ꂽ�Ƃ�
					{
						if (SlimeBX1[RespawnNumber[i + SAC]] < PlayerX2 && PlayerX1 < SlimeBX2[RespawnNumber[i + SAC]] && SlimeBY1[RespawnNumber[i + SAC]] < PlayerY2 && PlayerY1 < SlimeBY2[RespawnNumber[i + SAC]])
						{
							EnemyTouchFlag = 1;
						}
						else
						{
							EnemyTouchFlag = 0;
						}


					}
					if (EnemyTouchFlag == 1 && PlayerInvincibleFlag == 0)//�_���[�W���󂯂���� &�@���G�ł͂Ȃ�����
					{
						PlayerDamageFlag = 1;
					}
					else
					{
						PlayerDamageFlag = 0;
					}
					if (PlayerDamageFlag == 1)
					{
						PlayerInvincibleFlag = 1;
						PlayerLife = PlayerLife - 1;
					}
					if (PlayerInvincibleFlag == 1)//���G���Ԃ̃^�C�}�[
					{
						while (1)
						{
							PlayerInvincibleTimer -= 1;
							if (PlayerInvincibleTimer <= 0)
							{
								PlayerInvincibleTimer = 60;
								PlayerInvincibleFlag = 0;
							}
							break;
						}
					}
				}
				//--------------------------------------------------------------------------------------------------------------//
				if (EnemyCount == 0)
				{
					ClearWave = ClearWave + 1;
					RestartFlag = 1;
					EnemyCount = 5;
				}
				if (RestartFlag == 1)
				{
					while (1)
					{
						RestartTimer -= 1;
						if (RestartTimer <= 0)
						{
							EnemySelectFlag = 1;
							Map1_EnemyCoreX[0] = 870;
							Map1_EnemyCoreX[1] = 150;
							Map1_EnemyCoreX[2] = 990;
							Map1_EnemyCoreX[3] = 570;
							Map1_EnemyCoreX[4] = 720;

							Map1_EnemyCoreY[0] = 180;
							Map1_EnemyCoreY[1] = 360;
							Map1_EnemyCoreY[2] = 570;
							Map1_EnemyCoreY[3] = 630;
							Map1_EnemyCoreY[4] = 630;


							Map2_EnemyCoreX[0] = 360;
							Map2_EnemyCoreX[1] = 840;
							Map2_EnemyCoreX[2] = 1020;
							Map2_EnemyCoreX[3] = 90;
							Map2_EnemyCoreX[4] = 540;

							Map2_EnemyCoreY[0] = 120;
							Map2_EnemyCoreY[1] = 120;
							Map2_EnemyCoreY[2] = 420;
							Map2_EnemyCoreY[3] = 450;
							Map2_EnemyCoreY[4] = 540;


							Map3_EnemyCoreX[0] = 810;
							Map3_EnemyCoreX[1] = 270;
							Map3_EnemyCoreX[2] = 180;
							Map3_EnemyCoreX[3] = 930;
							Map3_EnemyCoreX[4] = 510;

							Map3_EnemyCoreY[0] = 120;
							Map3_EnemyCoreY[1] = 180;
							Map3_EnemyCoreY[2] = 480;
							Map3_EnemyCoreY[3] = 540;
							Map3_EnemyCoreY[4] = 750;
							if (ClearWave != 3)
							{
								for (int i = 0; i < 5; i++)
								{
									SlimeALife[i] = 2;
									SlimeAFlag[i] = 1;
									SlimeBLife[i] = 2;
									SlimeBFlag[i] = 1;
								}
							}
							if (ClearWave == 3)
							{
								for (int i = 0; i < 5; i++)
								{
									SlimeALife[i] = 0;
									SlimeAFlag[i] = 0;
									SlimeBLife[i] = 0;
									SlimeBFlag[i] = 0;
								}
								ClearWave = 0;
								StageClearFlag = 1;
							}


							RestartFlag = 0;
							RestartTimer = 120;
						}
						break;

					}

				}

				if (ClearDoorFlag == 1 && (EdgeInput & PAD_INPUT_4) != 0)
				{
					LoadFlag = 1;
					ClearDoorFlag = 0;
				}
				if (LoadFlag == 1)
				{

					while (1)
					{
						LoadMovieTimer -= 1;
						LoadTimer -= 1;
						if (LoadTimer <= 0)
						{

							LoadImageCount++;
							if (LoadImageCount == 19)
							{

								LoadImageCount = 0;
							}
						}
						if (LoadMovieTimer <= 0)
						{
							LoadMovieTimer = 150;
							StageClearFlag = 0;
							MapSelectFlag = 1;
							MapCraftFlag = 1;
							PlayerCoreX = 90;
							PlayerCoreY = 860;
							EnemySelectFlag = 1;
							for (int i = 0; i < 5; i++)
							{
								SlimeALife[i] = 2;
								SlimeAFlag[i] = 1;
								SlimeBLife[i] = 2;
								SlimeBFlag[i] = 1;
							}
							LoadFlag = 0;
						}
						break;

					}
				}
				if (keys[KEY_INPUT_SPACE] == 1 && oldkeys[KEY_INPUT_SPACE] == 0 && GameOverFlag == 1)
				{
					Gamescene = 0;
					GameOverFlag = 0;
				}

				//----------------------------------------------------------------�`�揈��--------------------------------------------------------------------------//
				  //----------------------------------�}�b�v�̕`��----------------------------------------------------------------//
				for (int i = 0; i < MapSizeY; i++)
				{
					for (int j = 0; j < MapSizeX; j++)
					{
						// �P�͓����蔻��`�b�v��\���Ă���̂łP�̂Ƃ��낾���`��
						if (MapData[i][j] == 1)
						{
							DrawBox(j * BlockSize, i * BlockSize, j * BlockSize + BlockSize, i * BlockSize + BlockSize, GetColor(100, 0, 255), false);
							DrawGraph(j * BlockSize, i * BlockSize, BlockImage, true);

						}
						if (MapData[i][j] == 2)
						{
							DrawBox(j * BlockSize, i * BlockSize, j * BlockSize + BlockSize, i * BlockSize + BlockSize, GetColor(100, 0, 100), false);
							DrawGraph(j * BlockSize, i * BlockSize, Ladder1Image, true);
						}
						if (MapData[i][j] == 3)
						{
							DrawBox(j * BlockSize, i * BlockSize, j * BlockSize + BlockSize, i * BlockSize + BlockSize, GetColor(100, 0, 50), false);
							DrawGraph(j * BlockSize, i * BlockSize, Ladder2Image, true);
						}
					}
				}
				//�h�A
				if (StageClearFlag == 0)
				{
					switch (MapSelect)
					{
						case 1:
							DrawGraph(1080, 570, DoorRockImage, true);
							break;
						case 2:
							DrawGraph(1080, 780, DoorRockImage, true);
							break;
						case 3:
							DrawGraph(1110, 420, DoorRockImage, true);
							break;
					}
				}
				if (StageClearFlag == 1)
				{
					switch (MapSelect)
					{
						case 1:
							DrawGraph(1080, 570, DoorImage, true);
							break;
						case 2:
							DrawGraph(1080, 780, DoorImage, true);
							break;
						case 3:
							DrawGraph(1110, 420, DoorImage, true);
							break;
					}
				}

				if (RestartFlag == 1)
				{
					while (1)
					{
						timer -= 1;
						if (timer <= 0)
						{
							timer = 3;
							t++;
							if (t == 10)
							{

								t = 0;
							}
						}
						break;

					}
				}
				if (RestartFlag == 1 && ClearWave != 3)
				{
					for (int i = 0; i < 5; i++)
					{
						if (MapSelect == 1)
						{
							DrawGraph(Respawn1_EnemyCoreX[i], Respawn1_EnemyCoreY[i], RespawnImage[t], true);
						}
						if (MapSelect == 2)
						{
							DrawGraph(Respawn2_EnemyCoreX[i], Respawn2_EnemyCoreY[i], RespawnImage[t], true);
						}
						if (MapSelect == 3)
						{
							DrawGraph(Respawn3_EnemyCoreX[i], Respawn3_EnemyCoreY[i], RespawnImage[t], true);
						}

					}
				}

				//----------------------------------�L�����N�^�̕`��-----------------------------------------------------------//
				  //-------------------------------------------�G���u----------------------------------//

			  //DrawBox((SlimeCoreX - SLIME_SIZE * 0.5F), (SlimeCoreY - SLIME_SIZE * 0.5F), (SlimeCoreX + SLIME_SIZE * 0.5F) + 1, (SlimeCoreY + SLIME_SIZE * 0.5F) + 1, GetColor(0, 255, 0), TRUE);
			  //DrawBox((SlimeCoreX - SLIME_SIZE * 0.5F), (SlimeCoreY - SLIME_SIZE * 0.5F) + 9 , (SlimeCoreX + SLIME_SIZE * 0.5F) + 1, (SlimeCoreY + SLIME_SIZE * 0.5F) + 1, GetColor(0, 55, 0), TRUE);
				//�X���C��A
				for (int i = 0; i < SAC; i++)
				{
					if (MapSelect == 1)
					{
						//DrawBox((Map1_EnemyCoreX[RespawnNumber[i]] - SlimeASearchRange), (Map1_EnemyCoreY[RespawnNumber[i]] - SlimeASearchRange), (Map1_EnemyCoreX[RespawnNumber[i]] + SlimeASearchRange), (Map1_EnemyCoreY[RespawnNumber[i]] + SlimeASearchRange), GetColor(255, 100, 200), false);
					}
					if (MapSelect == 2)
					{
						//DrawBox((Map2_EnemyCoreX[RespawnNumber[i]] - SlimeASearchRange), (Map2_EnemyCoreY[RespawnNumber[i]] - SlimeASearchRange), (Map2_EnemyCoreX[RespawnNumber[i]] + SlimeASearchRange), (Map2_EnemyCoreY[RespawnNumber[i]] + SlimeASearchRange), GetColor(255, 100, 200), false);
					}
					if (MapSelect == 3)
					{
						//DrawBox((Map3_EnemyCoreX[RespawnNumber[i]] - SlimeASearchRange), (Map3_EnemyCoreY[RespawnNumber[i]] - SlimeASearchRange), (Map3_EnemyCoreX[RespawnNumber[i]] + SlimeASearchRange), (Map3_EnemyCoreY[RespawnNumber[i]] + SlimeASearchRange), GetColor(255, 100, 200), false);
					}
					if (SlimeAFlag[RespawnNumber[i]] == 1 && SlimeADirection[RespawnNumber[i]] == 0)
					{
						DrawGraph(SlimeAX1[RespawnNumber[i]], SlimeAY1[RespawnNumber[i]], SlimeARightWaitImage, true);
					}
					if (SlimeAFlag[RespawnNumber[i]] == 1 && SlimeADirection[RespawnNumber[i]] == 1)
					{
						DrawGraph(SlimeAX1[RespawnNumber[i]], SlimeAY1[RespawnNumber[i]], SlimeALeftWaitImage, true);
					}
					if (SlimeAFlag[RespawnNumber[i]] == 1 && SlimeADirection[RespawnNumber[i]] == 2)
					{
						DrawGraph(SlimeAX1[RespawnNumber[i]], SlimeAY1[RespawnNumber[i]], SlimeALeftWaitImage, true);
					}
				}
				//�X���C��B
				for (int i = 0; i < SBC; i++)
				{
					if (MapSelect == 1)
					{
						//DrawBox((Map1_EnemyCoreX[RespawnNumber[i + SAC]] - SlimeBSearchRange), (Map1_EnemyCoreY[RespawnNumber[i + SAC]] - SlimeBSearchRange), (Map1_EnemyCoreX[RespawnNumber[i + SAC]] + SlimeBSearchRange), (Map1_EnemyCoreY[RespawnNumber[i + SAC]] + SlimeBSearchRange), GetColor(255, 100, 200), false);
					}
					if (MapSelect == 2)
					{
						//DrawBox((Map2_EnemyCoreX[RespawnNumber[i + SAC]] - SlimeBSearchRange), (Map2_EnemyCoreY[RespawnNumber[i + SAC]] - SlimeBSearchRange), (Map2_EnemyCoreX[RespawnNumber[i + SAC]] + SlimeBSearchRange), (Map2_EnemyCoreY[RespawnNumber[i + SAC]] + SlimeBSearchRange), GetColor(255, 100, 200), false);
					}
					if (MapSelect == 3)
					{
						//DrawBox((Map3_EnemyCoreX[RespawnNumber[i + SAC]] - SlimeBSearchRange), (Map3_EnemyCoreY[RespawnNumber[i + SAC]] - SlimeBSearchRange), (Map3_EnemyCoreX[RespawnNumber[i + SAC]] + SlimeBSearchRange), (Map3_EnemyCoreY[RespawnNumber[i + SAC]] + SlimeBSearchRange), GetColor(255, 100, 200), false);
					}
					if (SlimeBFlag[RespawnNumber[i + SAC]] == 1 && SlimeBDirection[RespawnNumber[i + SAC]] == 0)
					{
						DrawGraph(SlimeBX1[RespawnNumber[i + SAC]], SlimeBY1[RespawnNumber[i + SAC]], SlimeBRightWaitImage, true);
					}
					if (SlimeBFlag[RespawnNumber[i + SAC]] == 1 && SlimeBDirection[RespawnNumber[i + SAC]] == 1)
					{
						DrawGraph(SlimeBX1[RespawnNumber[i + SAC]], SlimeBY1[RespawnNumber[i + SAC]], SlimeBLeftWaitImage, true);
					}
					if (SlimeBFlag[RespawnNumber[i + SAC]] == 1 && SlimeBDirection[RespawnNumber[i + SAC]] == 2)
					{
						DrawGraph(SlimeBX1[RespawnNumber[i + SAC]], SlimeBY1[RespawnNumber[i + SAC]], SlimeBLeftWaitImage, true);
					}
				}
				//-------------------------------------------�v���C���[�̕`��------------------------------------//
			//DrawBox((PlayerCoreX - PLAYER_SIZE * 0.5F), (PlayerCoreY - PLAYER_SIZE * 0.5F), (PlayerCoreX + PLAYER_SIZE * 0.5F) + 1, (PlayerCoreY + PLAYER_SIZE * 0.5F) + 1, GetColor(255, 0, 0), TRUE);
			//DrawBox((PlX - CHAR_SIZE * 0.5F), (PlY - CHAR_SIZE * 0.5F) - 20, (PlX + CHAR_SIZE * 0.5F), (PlY + CHAR_SIZE * 0.5F), GetColor(255, 0, 0), TRUE);
				if (PlayerFlag == 1 && PlayerDirection == 0)
				{
					DrawGraph(PlayerX1, PlayerY1, PlayerRightWaitImage, true);
				}
				if (PlayerFlag == 1 && PlayerDirection == 1)
				{
					DrawGraph(PlayerX1, PlayerY1, PlayerLeftWaitImage, true);
				}
				//�v���C���[�̍U���`��
				if (PlayerFlag == 1 && PlayerDirection == 0 && PlayerAttackFlag == 1)
				{
					//DrawBox(PlayerSlashRIghtX, PlayerSlashRightY, PlayerSlashRIghtX + 51, PlayerSlashRightY + 39, GetColor(255, 255, 0), TRUE);
					DrawGraph(PlayerSlashRIghtX, PlayerSlashRightY, PlayerSlashRightImage, true);
				}
				if (PlayerFlag == 1 && PlayerDirection == 1 && PlayerAttackFlag == 1)
				{
					//DrawBox(PlayerSlashLeftX, PlayerSlashLeftY, PlayerSlashLeftX + 51, PlayerSlashLeftY + 39, GetColor(255, 255, 0), TRUE);
					DrawGraph(PlayerSlashLeftX, PlayerSlashLeftY, PlayerSlashLeftImage, true);
				}
				//�v���C���[�̃p�����[�^

				switch (PlayerLife)
				{
					case 0:
						DrawGraph(10, 10, PlayerHP0Image, true);
						DrawGraph(66, 10, PlayerHP0Image, true);
						DrawGraph(122, 10, PlayerHP0Image, true);
						break;
					case 1:
						DrawGraph(10, 10, PlayerHP1Image, true);
						DrawGraph(66, 10, PlayerHP0Image, true);
						DrawGraph(122, 10, PlayerHP0Image, true);
						break;
					case 2:
						DrawGraph(10, 10, PlayerHP2Image, true);
						DrawGraph(66, 10, PlayerHP0Image, true);
						DrawGraph(122, 10, PlayerHP0Image, true);
						break;
					case 3:
						DrawGraph(10, 10, PlayerHP2Image, true);
						DrawGraph(66, 10, PlayerHP1Image, true);
						DrawGraph(122, 10, PlayerHP0Image, true);
						break;
					case 4:
						DrawGraph(10, 10, PlayerHP2Image, true);
						DrawGraph(66, 10, PlayerHP2Image, true);
						DrawGraph(122, 10, PlayerHP0Image, true);
						break;
					case 5:
						DrawGraph(10, 10, PlayerHP2Image, true);
						DrawGraph(66, 10, PlayerHP2Image, true);
						DrawGraph(122, 10, PlayerHP1Image, true);
						break;
					case 6:
						DrawGraph(10, 10, PlayerHP2Image, true);
						DrawGraph(66, 10, PlayerHP2Image, true);
						DrawGraph(122, 10, PlayerHP2Image, true);
						break;

				}


				if (PlayerAttackRecharge <= 35)
				{
					DrawGraph(10, 71, AttackTimer0Image, true);
				}
				if (PlayerAttackRecharge <= 30)
				{
					DrawGraph(10, 71, AttackTimer3Image, true);
				}
				if (PlayerAttackRecharge <= 24)
				{
					DrawGraph(10, 71, AttackTimer6Image, true);
				}
				if (PlayerAttackRecharge <= 18)
				{
					DrawGraph(10, 71, AttackTimer9Image, true);
				}
				if (PlayerAttackRecharge <= 12)
				{
					DrawGraph(10, 71, AttackTimer12Image, true);
				}
				if (PlayerAttackRecharge <= 6 || PlayerAttackRecharge == 36)
				{
					DrawGraph(10, 71, AttackTimer15Image, true);
				}

				if (ClearDoorFlag == 1)
				{
					DrawGraph(PlayerX1 + 57, PlayerY1 - 45, YbuttonImage, true);
				}

				if (LoadFlag == 1)
				{
					DrawGraph(0, 0, LoadMImage[LoadImageCount], true);
				}


				if (GameOverFlag == 1)
				{
					DrawGraph(0, 0, GameOverImage, true);
				}





				
				
		}



		
		//---------  �����܂łɃv���O�������L�q  ---------//
		// (�_�u���o�b�t�@)����
		ScreenFlip();

		// 20�~���b�ҋ@(�^��60FPS)
		WaitTimer(20);

		// Windows�V�X�e�����炭�������������
		if (ProcessMessage() == -1)
		{
			break;
		}

		// ESC�L�[�������ꂽ�烋�[�v���甲����
		if (CheckHitKey(KEY_INPUT_ESCAPE) == 1)
		{
			break;
		}
	}
	// Dx���C�u�����I������
	DxLib_End();

	// ����I��
	return 0;
}








// �L�����N�^���}�b�v�Ƃ̓����蔻����l�����Ȃ���ړ�����
int CharMove(float* X, float* Y, float* DownSP,
	float MoveX, float MoveY, float Size, char* JumpFlag)
{
	float Dummy = 0.0F;
	float hsize;

	// �L�����N�^�̍���A�E��A�����A�E�������������蔻��̂���
	// �}�b�v�ɏՓ˂��Ă��邩���ׁA�Փ˂��Ă�����␳����

	// �����̃T�C�Y���Z�o
	hsize = Size * 0.5F;

	// �悸�㉺�ړ����������Ń`�F�b�N
	{
		// �����̃`�F�b�N�A�����u���b�N�̏�ӂɒ����Ă����痎�����~�߂�
		if (MapHitCheck(*X - hsize, *Y + hsize, &Dummy, &MoveY) == 3) *DownSP = 0.0F;

		// �E���̃`�F�b�N�A�����u���b�N�̏�ӂɒ����Ă����痎�����~�߂�
		if (MapHitCheck(*X + hsize, *Y + hsize, &Dummy, &MoveY) == 3) *DownSP = 0.0F;

		// ����̃`�F�b�N�A�����u���b�N�̉��ӂɓ������Ă����痎��������
		if (MapHitCheck(*X - hsize, *Y - hsize, &Dummy, &MoveY) == 4) *DownSP *= -1.0F;

		// �E��̃`�F�b�N�A�����u���b�N�̉��ӂɓ������Ă����痎��������
		if (MapHitCheck(*X + hsize, *Y - hsize, &Dummy, &MoveY) == 4) *DownSP *= -1.0F;

		// �㉺�ړ����������Z
		*Y += MoveY;
	}

	// ��ɍ��E�ړ����������Ń`�F�b�N
	{
		// �����̃`�F�b�N
		MapHitCheck(*X - hsize, *Y + hsize, &MoveX, &Dummy);

		// �E���̃`�F�b�N
		MapHitCheck(*X + hsize, *Y + hsize, &MoveX, &Dummy);

		// ����̃`�F�b�N
		MapHitCheck(*X - hsize, *Y - hsize, &MoveX, &Dummy);

		// �E��̃`�F�b�N
		MapHitCheck(*X + hsize, *Y - hsize, &MoveX, &Dummy);

		// ���E�ړ����������Z
		*X += MoveX;
	}

	// �ڒn����
	{
		// �L�����N�^�̍����ƉE���̉��ɒn�ʂ����邩���ׂ�
		if (GetChipParam(*X - Size * 0.5F, *Y + Size * 0.5F + 1.0F) == 0 &&
			GetChipParam(*X + Size * 0.5F, *Y + Size * 0.5F + 1.0F) == 0)
		{
			// ���ꂪ����������W�����v���ɂ���
			*JumpFlag = TRUE;
		}
		else
		{
			// ���ꂪ�݂�����ڒn���ɂ���
			*JumpFlag = FALSE;
		}
	}

	// �I��
	return 0;
}

// �}�b�v�Ƃ̓����蔻��( �߂�l 0:������Ȃ�����  1:���ӂɓ�������  2:�E�ӂɓ������� 3:��ӂɓ�������  4:���ӂɓ�������
int MapHitCheck(float X, float Y,
	float* MoveX, float* MoveY)
{
	float afX, afY;

	// �ړ��ʂ𑫂�
	afX = X + *MoveX;
	afY = Y + *MoveY;

	// �����蔻��̂���u���b�N�ɓ������Ă��邩�`�F�b�N
	if (GetChipParam(afX, afY) == 1)
	{
		float blx, bty, brx, bby;

		// �������Ă�����ǂ��痣���������s��

		// �u���b�N�̏㉺���E�̍��W���Z�o
		blx = (float)((int)afX / BlockSize) * BlockSize;        // ���ӂ� X ���W
		brx = (float)((int)afX / BlockSize + 1) * BlockSize;    // �E�ӂ� X ���W

		bty = (float)((int)afY / BlockSize) * BlockSize;        // ��ӂ� Y ���W
		bby = (float)((int)afY / BlockSize + 1) * BlockSize;    // ���ӂ� Y ���W

		// ��ӂɓ������Ă����ꍇ
		if (*MoveY > 0.0F)
		{
			// �ړ��ʂ�␳����
			*MoveY = bty - Y - 1.0F;

			// ��ӂɓ��������ƕԂ�
			return 3;
		}

		// ���ӂɓ������Ă����ꍇ
		if (*MoveY < 0.0F)
		{
			// �ړ��ʂ�␳����
			*MoveY = bby - Y + 1.0F;

			// ���ӂɓ��������ƕԂ�
			return 4;
		}

		// ���ӂɓ������Ă����ꍇ
		if (*MoveX > 0.0F)
		{
			// �ړ��ʂ�␳����
			*MoveX = blx - X - 1.0F;

			// ���ӂɓ��������ƕԂ�
			return 1;
		}

		// �E�ӂɓ������Ă����ꍇ
		if (*MoveX < 0.0F)
		{
			// �ړ��ʂ�␳����
			*MoveX = brx - X + 1.0F;

			// �E�ӂɓ��������ƕԂ�
			return 2;
		}

		// �����ɗ�����K���Ȓl��Ԃ�
		return 4;
	}

	// �ǂ��ɂ�������Ȃ������ƕԂ�
	return 0;
}

// �}�b�v�`�b�v�̒l���擾����֐�
int GetChipParam(float X, float Y)
{
	int x, y;

	// �����l�֕ϊ�
	x = (int)X / BlockSize;
	y = (int)Y / BlockSize;

	// �}�b�v����͂ݏo�Ă����� 0 ��Ԃ�
	if (x >= MapSizeX || y >= MapSizeY || x < 0 || y < 0) return 0;

	// �w��̍��W�ɊY������}�b�v�̏���Ԃ�
	return MapData[y][x];
}


