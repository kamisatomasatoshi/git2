#include "DxLib.h"

#include<time.h>
// �E�B���h�E�̃^�C�g���ɕ\�����镶����
const char TITLE[] = "LC1D_23_�~�X�~�J�h";

// �E�B���h�E����
const int WIN_WIDTH = 832;

// �E�B���h�E�c��
const int WIN_HEIGHT = 512;

int WINAPI WinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ LPSTR lpCmdLine, _In_ int nCmdShow)
{
	// �E�B���h�E���[�h�ɐݒ�
	ChangeWindowMode(TRUE);

	// �E�B���h�E�T�C�Y���蓮�ł͕ύX�������A
	// ���E�B���h�E�T�C�Y�ɍ��킹�Ċg��ł��Ȃ��悤�ɂ���
	SetWindowSizeChangeEnableFlag(FALSE, FALSE);

	// �^�C�g����ύX
	SetMainWindowText(TITLE);

	// ��ʃT�C�Y�̍ő�T�C�Y�A�J���[�r�b�g����ݒ�(���j�^�[�̉𑜓x�ɍ��킹��)
	SetGraphMode(WIN_WIDTH, WIN_HEIGHT, 32);

	// ��ʃT�C�Y��ݒ�(�𑜓x�Ƃ̔䗦�Őݒ�)
	SetWindowSizeExtendRate(1.0);

	// ��ʂ̔w�i�F��ݒ肷��
	SetBackgroundColor(255, 255, 255);

	// DXlib�̏�����
	if (DxLib_Init() == -1) { return -1; }

	// (�_�u���o�b�t�@)�`���O���t�B�b�N�̈�͗��ʂ��w��
	SetDrawScreen(DX_SCREEN_BACK);

	// �摜�Ȃǂ̃��\�[�X�f�[�^�̕ϐ��錾�Ɠǂݍ���


	// �Q�[�����[�v�Ŏg���ϐ��̐錾

	//�摜�̓ǂݍ���
	int harinezumi1 = LoadGraph("harinezumi1.png");	//�n���l�Y�~�P�̉摜�ǂݍ���
	int harinezumi2 = LoadGraph("harinezumi2.png"); ;//�n���l�Y�~�Q�̉摜�ǂݍ���
	int harinezumi3 = LoadGraph("harinezumi3.png");;//�n���l�Y�~�R�̉摜�ǂݍ���
	int harinezumi4 = LoadGraph("harinezumi4.png");//�n���l�Y�~�S�̉摜�ǂݍ���
	int harinezumi5 = LoadGraph("harinezumi5.png");//�n���l�Y�~�T�̉摜�ǂݍ���
	int harinezumi6 = LoadGraph("harinezumi6.png");//�n���l�Y�~�U�̉摜�ǂݍ���
	int donguri = LoadGraph("donguri.png");//�ǂ񂮂�摜�̓ǂݍ���
	int select = LoadGraph("select.png");//�Z���N�g�̘g�摜�̓ǂݍ���
	int haikei = LoadGraph("haikei.png");//�w�i�摜�̓ǂݍ���
	int end = LoadGraph("end.png");//�G���f�B���O�摜�ǂݍ���
	int title[8];
	LoadDivGraph("title.png", 8, 8, 1,832, 512, title);
	int number[9];
	LoadDivGraph("number.png", 10, 10, 1, 320, 32, number);
	int mainbgm = 0;
	mainbgm = LoadSoundMem("main.mp3");
	//�Q�[���̏����ݒ�
	int basebord[8][8] = {
		{0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0},
	};

	int btate = 0;
	int byoko = 0;
	int startf = 0;
	int selectx = 0;
	int selecty = 0;
	int tugi = 0;
	int scene = 0;
	int ct = 20;
	int i = 0;
	int cf = 1;
	int score = 0;
	int highscore = 0;
	int num[3] = {};
	
	int break3if = 0;
	int break3it = 250;
	int break3jf = 0;
	int break3jt = 250;

	int break4if = 0;
	int break4it = 250;
	int break4jf = 0;
	int break4jt = 250;

	int break5if = 0;
	int break5it = 250;
	int break5jf = 0;
	int break5jt = 250;

	int syuryouf = 0;

	srand(time(nullptr));

	// �ŐV�̃L�[�{�[�h���p
	char keys[256] = { 0 };

	// 1���[�v(�t���[��)�O�̃L�[�{�[�h���
	char oldkeys[256] = { 0 };

	// �Q�[�����[�v
	while (1)
	{
		// �ŐV�̃L�[�{�[�h��񂾂������̂�1�t���[���O�̃L�[�{�[�h���Ƃ��ĕۑ�
		for (int i = 0; i < 256; i++) 
		{
			oldkeys[i] = keys[i];
		}

		// �ŐV�̃L�[�{�[�h�����擾
		
		GetHitKeyStateAll(keys);

		// ��ʃN���A
		ClearDrawScreen();

		
		switch (scene) {
		case 0:
			//����������
			for (int j = 0; j < 8; j++) {
				for (int i = 0; i < 8; i++) {
					basebord[i][j] = 0;
				}
			}
			score = 0;
		 syuryouf = 0;
			//�X�V����
			if (cf == 1) {
				ct = ct - 1;
				if (ct == 0) {
					i++;
					ct = 20;
				}
				if (i == 8) {
					i = 0;
				}
				DrawGraph(0, 0, title[i], TRUE);
			}
			if (keys[KEY_INPUT_SPACE] == 1 && oldkeys[KEY_INPUT_SPACE] == 0) {
				scene = 1;
			}
			//�`�揈��
			SetBackgroundColor(255,255,255);
			PlaySoundMem(mainbgm, DX_PLAYTYPE_BACK, true);
			break;
		case 1:
			DrawGraph(0, 0, haikei, true);
			// �X�V����
			if (keys[KEY_INPUT_SPACE] == 1 && oldkeys[KEY_INPUT_SPACE] == 0) {
				basebord[selecty][selectx] = tugi;
			}

			if (keys[KEY_INPUT_SPACE] == 1 && oldkeys[KEY_INPUT_SPACE] == 0) {
				startf = 1;
				int tugi1 = rand() % 6 + 1;
				tugi = tugi1;
			}

			if (startf == 1) {
				for (int yoko = 0; yoko < 8; yoko++) {
					//��ԏ�̍s�ɗ���������	
					int ransu = rand() % 12;
					if (ransu == 7||ransu == 8 || ransu == 9 || ransu == 10 || ransu == 11 || ransu == 12) {
						ransu = 0;
					}
					basebord[0][yoko] = ransu;
					startf = 0;
				}
			}
			for (int j = 0; j < 8; j++) {
				for (int i = 0; i < 8; i++) {
					if (basebord[i][j] != 7) {
						for (int yoko = 0; yoko < 8; yoko++) {
							for (int tate = 0; tate < 8; tate++) {
								if (basebord[tate + 1][yoko] == 0) {
									basebord[tate + 1][yoko] = basebord[tate][yoko];
									basebord[tate][yoko] = 0;
								}
							}
						}
					}
				}
			}
			for (int checki = 0; checki < 8; checki++) {
				for (int checkj = 0; checkj < 8; checkj++) {
					for (int checkj = 0; checkj < 8; checkj++) {
						//5�̎�
						if (basebord[checki][checkj] != 0 && basebord[checki][checkj] == basebord[checki + 1][checkj] && basebord[checki + 1][checkj] == basebord[checki + 2][checkj] && basebord[checki + 2][checkj] == basebord[checki + 3][checkj] && basebord[checki + 3][checkj] == basebord[checki + 4][checkj]) {
							basebord[checki][checkj] = 7;
							basebord[checki + 1][checkj] = 7;
							basebord[checki + 2][checkj] = 7;
							basebord[checki + 3][checkj] = 7;
							basebord[checki + 4][checkj] = 7;
						}
						if (basebord[checki][checkj] != 0 && basebord[checki][checkj] == basebord[checki][checkj + 1] && basebord[checki][checkj + 1] == basebord[checki][checkj + 2] && basebord[checki][checkj + 2] == basebord[checki][checkj + 3] && basebord[checki][checkj + 3] == basebord[checki][checkj + 4]) {
							basebord[checki][checkj] = 7;
							basebord[checki][checkj + 1] = 7;
							basebord[checki][checkj + 2] = 7;
							basebord[checki][checkj + 3] = 7;
							basebord[checki][checkj + 4] = 7;
						}
						if (basebord[checki][checkj] != 0 && basebord[checki][checkj] == basebord[checki + 1][checkj] && basebord[checki + 1][checkj] == basebord[checki + 2][checkj] && basebord[checki + 2][checkj] == basebord[checki + 3][checkj] && basebord[checki + 3][checkj] == basebord[checki + 4][checkj]) {
							break5it = break5it - 1;
						}
						if (basebord[checki][checkj] != 0 && basebord[checki][checkj] == basebord[checki][checkj + 1] && basebord[checki][checkj + 1] == basebord[checki][checkj + 2] && basebord[checki][checkj + 2] == basebord[checki][checkj + 3] && basebord[checki][checkj + 3] == basebord[checki][checkj + 4]) {
							break5jt = break5jt - 1;
						}
						if (break5it == 0) {
							score = score + 10;
							break5if = 1;
						}
						if (break5jt == 0) {
							score = score + 10;
							break5jf = 1;
						}
						if (break5if == 1) {
							for (int j = 0; j < 8; j++) {
								for (int i = 0; i < 8; i++) {
									if (basebord[i][j] == 7) {
										basebord[i][j] = 0;
									}
								}
							}
							break5it = 250;
							break5if = 0;
						}
						if (break5jf == 1) {
							for (int j = 0; j < 8; j++) {
								for (int i = 0; i < 8; i++) {
									if (basebord[i][j] == 7) {
										basebord[i][j] = 0;
									}
								}
							}
							break5jt = 250;
							break5jf = 0;
						}

						//�S�̎�
						if (basebord[checki][checkj] != 0 && basebord[checki][checkj] == basebord[checki + 1][checkj] && basebord[checki + 1][checkj] == basebord[checki + 2][checkj] && basebord[checki + 2][checkj] == basebord[checki + 3][checkj]) {
							basebord[checki][checkj] = 7;
							basebord[checki + 1][checkj] = 7;
							basebord[checki + 2][checkj] = 7;
							basebord[checki + 3][checkj] = 7;
						}
						if (basebord[checki][checkj] != 0 && basebord[checki][checkj] == basebord[checki][checkj + 1] && basebord[checki][checkj + 1] == basebord[checki][checkj + 2] && basebord[checki][checkj + 2] == basebord[checki][checkj + 3]) {
							basebord[checki][checkj] = 7;
							basebord[checki][checkj + 1] = 7;
							basebord[checki][checkj + 2] = 7;
							basebord[checki][checkj + 3] = 7;
						}
						if (basebord[checki][checkj] != 0 && basebord[checki][checkj] == basebord[checki + 1][checkj] && basebord[checki + 1][checkj] == basebord[checki + 2][checkj] && basebord[checki + 2][checkj] == basebord[checki + 3][checkj]) {
							break4it = break4it - 1;
						}
						if (basebord[checki][checkj] != 0 && basebord[checki][checkj] == basebord[checki][checkj + 1] && basebord[checki][checkj + 1] == basebord[checki][checkj + 2] && basebord[checki][checkj + 2] == basebord[checki][checkj + 3]) {
							break4jt = break4jt - 1;
						}
						if (break4it == 0) {
							score = score + 5;
							break4if = 1;
						}
						if (break4jt == 0) {
							score = score + 5;
							break4jf = 1;
						}
						if (break4if == 1) {
							for (int j = 0; j < 8; j++) {
								for (int i = 0; i < 8; i++) {
									if (basebord[i][j] == 7) {
										basebord[i][j] = 0;
									}
								}
							}
							break4it = 250;
							break4if = 0;
						}
						if (break4jf == 1) {
							for (int j = 0; j < 8; j++) {
								for (int i = 0; i < 8; i++) {
									if (basebord[i][j] == 7) {
										basebord[i][j] = 0;
									}
								}
							}
							break4jt = 250;
							break4jf = 0;
						}
						//3�̎�
						if (basebord[checki][checkj] != 0 && basebord[checki][checkj] == basebord[checki + 1][checkj] && basebord[checki + 1][checkj] == basebord[checki + 2][checkj]) {
							basebord[checki][checkj] = 7;
							basebord[checki + 1][checkj] = 7;
							basebord[checki + 2][checkj] = 7;
						}
						if (basebord[checki][checkj] != 0 && basebord[checki][checkj] == basebord[checki][checkj + 1] && basebord[checki][checkj + 1] == basebord[checki][checkj + 2]) {
							basebord[checki][checkj] = 7;
							basebord[checki][checkj + 1] = 7;
							basebord[checki][checkj + 2] = 7;
						}
						if (basebord[checki][checkj] != 0 && basebord[checki][checkj] == basebord[checki][checkj + 1] && basebord[checki][checkj + 1] == basebord[checki][checkj + 2]) {
							break3jt = break3jt - 1;
						}
						if (basebord[checki][checkj] != 0 && basebord[checki][checkj] == basebord[checki + 1][checkj] && basebord[checki + 1][checkj] == basebord[checki + 2][checkj]) {
							break3it = break3it - 1;
						}
						if (break3it == 0) {
							score = score + 3;
							break3if = 1;
						}
						if (break3jt == 0) {
							score = score + 3;
							break3jf = 1;
						}
						if (break3if == 1) {
							for (int j = 0; j < 8; j++) {
								for (int i = 0; i < 8; i++) {
									if (basebord[i][j] == 7) {
										basebord[i][j] = 0;
									}
								}
							}
							break3it = 250;
							break3if = 0;
						}
						if (break3jf == 1) {
							for (int j = 0; j < 8; j++) {
								for (int i = 0; i < 8; i++) {
									if (basebord[i][j] == 7) {
										basebord[i][j] = 0;
									}
								}
							}
							break3jt = 250;
							break3jf = 0;
						}
					}
				}
			}
			if (highscore < score) {
				highscore = score;
			}
			// �`�揈��
			if (keys[KEY_INPUT_RIGHT] == 1 && oldkeys[KEY_INPUT_RIGHT] == 0) {
				selectx = selectx + 1;
			}
			if (keys[KEY_INPUT_LEFT] == 1 && oldkeys[KEY_INPUT_LEFT] == 0) {
				selectx = selectx - 1;
			}
			if (keys[KEY_INPUT_UP] == 1 && oldkeys[KEY_INPUT_UP] == 0) {
				selecty = selecty - 1;
			}
			if (keys[KEY_INPUT_DOWN] == 1 && oldkeys[KEY_INPUT_DOWN] == 0) {
				selecty = selecty + 1;
			}
			if (selectx < 0) {
				selectx = 0;
			}
			if (selectx > 7) {
				selectx = 7;
			}
			if (selecty < 0) {
				selecty = 0;
			}
			if (selecty > 7) {
				selecty = 7;
			}

			for (int i = 0; i < 8; i++) {
				for (int j = 0; j < 8; j++) {
					if (basebord[i][j] == 1) {
						DrawGraph(j * 64, i * 64, harinezumi1, true);
					}
					if (basebord[i][j] == 2) {
						DrawGraph(j * 64, i * 64, harinezumi2, true);
					}
					if (basebord[i][j] == 3) {
						DrawGraph(j * 64, i * 64, harinezumi3, true);
					}
					if (basebord[i][j] == 4) {
						DrawGraph(j * 64, i * 64, harinezumi4, true);
					}
					if (basebord[i][j] == 5) {
						DrawGraph(j * 64, i * 64, harinezumi5, true);
					}
					if (basebord[i][j] == 6) {
						DrawGraph(j * 64, i * 64, harinezumi6, true);
					}
					if (basebord[i][j] == 7) {
						DrawGraph(j * 64, i * 64, donguri, true);
					}
				}
			}

			if (tugi == 1) {
				DrawGraph(580, 60, harinezumi1, true);
			}
			if (tugi == 2) {
				DrawGraph(580, 60, harinezumi2, true);
			}
			if (tugi == 3) {
				DrawGraph(580, 60, harinezumi3, true);
			}
			if (tugi == 4) {
				DrawGraph(580, 60, harinezumi4, true);
			}
			if (tugi == 5) {
				DrawGraph(580, 60, harinezumi5, true);
			}
			if (tugi == 6) {
				DrawGraph(580, 60, harinezumi6, true);
			}
			DrawGraph(selectx * 64, selecty * 64, select, true);
			DrawFormatString(580, 300, GetColor(0, 0, 0), "highscore  %d", highscore);
			DrawFormatString(580, 320, GetColor(0, 0, 0), "score  %d", score);

			for (int i = 0; i < 8; i++) {
				for (int j = 0; j < 8; j++) {
					if (basebord[i][j] != 7) {
						syuryouf = 1;
					}
				}
			}
			if (syuryouf == 1) {
				for (int yoko = 0; yoko < 8; yoko++) {
					if (basebord[0][yoko] != 0) {
						StopSoundMem(mainbgm);
						scene = 2;
					}
					if (basebord[0][yoko] == 0) {
						syuryouf = 0;
					}
				}
			}
			break;
			case 2:
				//����������
				//�X�V����
				if (keys[KEY_INPUT_SPACE] == 1 && oldkeys[KEY_INPUT_SPACE] == 0) {
					scene = 0;
				}
				//�`�揈��
				SetBackgroundColor(255,255,255);
				DrawGraph(0, 0, end, true);
				DrawFormatString(400, 200, GetColor(0, 0, 0), "%d", highscore);
				DrawFormatString(400, 350, GetColor(0, 0, 0), "%d", score);
				break;
		}


		//---------  �����܂łɃv���O�������L�q  ---------//
		// (�_�u���o�b�t�@)����
		ScreenFlip();

		// 20�~���b�ҋ@(�^��60FPS)
		WaitTimer(20);

		// Windows�V�X�e�����炭�������������
		if (ProcessMessage() == -1)
		{
			break;
		}

		// ESC�L�[�������ꂽ�烋�[�v���甲����
		if (CheckHitKey(KEY_INPUT_ESCAPE) == 1)
		{
			break;
		}
	}
	// Dx���C�u�����I������
	DxLib_End();

	// ����I��
	return 0;
};