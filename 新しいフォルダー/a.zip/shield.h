#pragma once
#include "structure.h"

void PlayerShield(
	Object& player,
	Shield& playerShield,
	Mouse& mouseStructure,
	int enemyBulletX,
	int enemyBulletY,
	const int enemyBulletRadius,
	Boomerang& boomerang
);
