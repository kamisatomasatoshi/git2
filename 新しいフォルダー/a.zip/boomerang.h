#pragma once
#include "structure.h"
#include <math.h>

void PlayerBoomerang(Object& player, Boomerang& boomerang, Mouse& mouseStructure, Transform& target,int isAirJump);