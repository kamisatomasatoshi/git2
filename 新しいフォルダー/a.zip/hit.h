#pragma once
#include "structure.h"

void HitDecision(Object& player,Boomerang& boomerang, Shield& playerShield, ENEMY& bossLeftHand, ENEMY& bossRightHand, ENEMY& bossFace, Bullet enemyBullet[]);